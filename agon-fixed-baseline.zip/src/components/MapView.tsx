import { useEffect, useRef, useState, useCallback } from 'react';
import type { Map as MLMap, Marker as MLMarker } from 'maplibre-gl';
import { useThemeStore } from '../stores/themeStore';
import { cn } from '../lib/utils';

// ── Types (public interface unchanged — callers need no edits) ─────────
interface MarkerData {
  lat: number;
  lng: number;
  label?: string;
  color?: string;
  popup?: string;
  icon?: 'pin' | 'rider' | 'bike' | 'pickup' | 'dropoff';
}

interface MapViewProps {
  center?: [number, number];
  zoom?: number;
  markers?: MarkerData[];
  route?: Array<[number, number]>;
  /** Secondary route (e.g. rider → pickup) drawn as a dashed neutral line */
  secondaryRoute?: Array<[number, number]>;
  onMapClick?: (lat: number, lng: number) => void;
  className?: string;
  interactive?: boolean;
  pinDropActive?: boolean;
}

// ── Mapbox style + token ───────────────────────────────────────────────
const MAPBOX_TOKEN =
  (import.meta.env.VITE_MAPBOX_TOKEN as string) ||
  'pk.eyJ1Ijoia2VsazciLCJhIjoiY210M2h3bTBvMTBjajJ5c2s2dDhsNHJtbyJ9.ltCbsxU-tOFi2rVNMeGLuQ';

// Our custom Mapbox Studio style (larger text + visible POI icons),
// loaded directly by URL — MapLibre renders it as vector tiles.
const STYLE_URL =
  `https://api.mapbox.com/styles/v1/kelk7/cmtavxnok004e01qq7f9vczox?access_token=${MAPBOX_TOKEN}`;

// Mapbox styles reference resources via the proprietary `mapbox://`
// protocol. MapLibre doesn't know it, so resolve those URLs to the
// Mapbox HTTP API and attach the access token to every api.mapbox.com
// request (tiles, TileJSON, sprite, glyphs).
function transformRequest(url: string) {
  let u = url;
  if (u.startsWith('mapbox://')) {
    const rest = u.slice('mapbox://'.length);
    if (rest.startsWith('sprites/')) {
      const parts = rest.slice('sprites/'.length).split('/');
      const user = parts[0];
      const style = parts[1];
      const last = parts[parts.length - 1] || '';
      const suffixMatch = last.match(/(@2x)?\.(json|png)$/);
      const suffix = suffixMatch ? suffixMatch[0] : '.json';
      u = `https://api.mapbox.com/styles/v1/${user}/${style}/sprite${suffix}`;
    } else if (rest.startsWith('fonts/')) {
      u = `https://api.mapbox.com/fonts/v1/${rest.slice('fonts/'.length)}`;
    } else {
      u = `https://api.mapbox.com/v4/${rest}.json?secure`;
    }
  }
  if (u.includes('api.mapbox.com') && !u.includes('access_token')) {
    u += (u.includes('?') ? '&' : '?') + `access_token=${MAPBOX_TOKEN}`;
  }
  return { url: u };
}

// ── Style sanitizer ──────────────────────────────────────────────────
// Mapbox Studio exports can contain things MapLibre can't parse:
//   1. Deprecated "property function" syntax {"property": X, "stops": [...]}
//   2. Mapbox-proprietary paint/layout keys (e.g. icon-size-scale-range,
//      text-size-scale-range) — MapLibre looks the key up in its spec,
//      gets undefined, and crashes with "Cannot read properties of
//      undefined (reading 'property')"
//   3. Root-level "fog" and {"projection": {"name": ...}} (Mapbox shape)
// The scanner silently auto-fixes what it safely can so the style
// renders immediately.
const KNOWN_LAYOUT_KEYS: Record<string, string[]> = {
  background: [],
  fill: ['fill-sort-key'],
  line: ['line-cap', 'line-join', 'line-miter-limit', 'line-round-limit', 'line-sort-key'],
  circle: ['circle-sort-key'],
  heatmap: [],
  hillshade: [],
  raster: [],
  symbol: [
    'symbol-placement', 'symbol-spacing', 'symbol-avoid-edges', 'symbol-sort-key',
    'symbol-z-order', 'symbol-z-elev',
    'icon-allow-overlap', 'icon-ignore-placement', 'icon-optional', 'icon-rotation-alignment',
    'icon-size', 'icon-text-fit', 'icon-text-fit-padding', 'icon-image', 'icon-rotate',
    'icon-padding', 'icon-keep-upright', 'icon-offset', 'icon-anchor', 'icon-pitch-alignment',
    'text-pitch-alignment', 'text-rotation-alignment', 'text-field', 'text-font', 'text-size',
    'text-max-width', 'text-line-height', 'text-letter-spacing', 'text-justify',
    'text-radial-offset', 'text-variable-anchor', 'text-variable-anchor-offset', 'text-anchor',
    'text-max-angle', 'text-writing-mode', 'text-rotate', 'text-padding', 'text-keep-upright',
    'text-transform', 'text-offset', 'text-allow-overlap', 'text-ignore-placement', 'text-optional',
  ],
};

const KNOWN_PAINT_KEYS: Record<string, string[]> = {
  background: ['background-color', 'background-pattern', 'background-opacity'],
  fill: ['fill-antialias', 'fill-opacity', 'fill-color', 'fill-outline-color', 'fill-translate', 'fill-translate-anchor', 'fill-pattern', 'fill-blur', 'fill-z-offset'],
  line: ['line-opacity', 'line-color', 'line-translate', 'line-translate-anchor', 'line-width', 'line-gap-width', 'line-offset', 'line-blur', 'line-dasharray', 'line-pattern', 'line-gradient', 'line-border-width', 'line-border-color'],
  circle: ['circle-radius', 'circle-color', 'circle-blur', 'circle-opacity', 'circle-translate', 'circle-translate-anchor', 'circle-pitch-scale', 'circle-pitch-alignment', 'circle-stroke-width', 'circle-stroke-color', 'circle-stroke-opacity'],
  heatmap: ['heatmap-radius', 'heatmap-weight', 'heatmap-intensity', 'heatmap-color', 'heatmap-opacity'],
  hillshade: ['hillshade-illumination-direction', 'hillshade-illumination-anchor', 'hillshade-exaggeration', 'hillshade-shadow-color', 'hillshade-highlight-color', 'hillshade-accent-color'],
  raster: ['raster-opacity', 'raster-hue-rotate', 'raster-brightness-min', 'raster-brightness-max', 'raster-saturation', 'raster-contrast', 'raster-resampling', 'raster-fade-duration'],
  symbol: ['icon-opacity', 'icon-color', 'icon-halo-color', 'icon-halo-width', 'icon-halo-blur', 'icon-translate', 'icon-translate-anchor', 'text-opacity', 'text-color', 'text-halo-color', 'text-halo-width', 'text-halo-blur', 'text-translate', 'text-translate-anchor'],
};

function isLegacyFunctionValue(v: unknown): boolean {
  if (typeof v !== 'object' || v === null || Array.isArray(v)) return false;
  const o = v as Record<string, unknown>;
  return 'property' in o || Array.isArray(o.stops);
}

// {"stops": [[z1,v1],[z2,v2]]} → ["interpolate", ["linear"], ["zoom"], z1, v1, z2, v2]
function convertLegacyZoomFunction(fn: Record<string, unknown>): unknown[] | null {
  const stops = fn.stops;
  if (!Array.isArray(stops) || stops.length === 0) return null;
  const flat: unknown[] = [];
  for (const stop of stops) {
    if (!Array.isArray(stop) || stop.length !== 2 || typeof stop[0] !== 'number') return null;
    flat.push(stop[0], stop[1]);
  }
  return ['interpolate', ['linear'], ['zoom'], ...flat];
}

function sanitizeStyle(style: any): any {
  if (!style || typeof style !== 'object') return style;

  // Root-level Mapbox-only properties
  if (style.fog) delete style.fog;
  if (style.projection && typeof style.projection === 'object' && style.projection.name && !style.projection.type) {
    style.projection = { type: style.projection.name };
  }

  for (const layer of Array.isArray(style.layers) ? style.layers : []) {
    if (!layer || typeof layer !== 'object') continue;
    for (const bucket of ['layout', 'paint'] as const) {
      const obj = layer[bucket];
      if (!obj || typeof obj !== 'object') continue;
      const known = (bucket === 'layout' ? KNOWN_LAYOUT_KEYS : KNOWN_PAINT_KEYS)[layer.type];
      for (const [key, value] of Object.entries(obj)) {
        // 1) Deprecated property-function syntax
        if (isLegacyFunctionValue(value)) {
          const fn = value as Record<string, unknown>;
          const referenced = typeof fn.property === 'string' ? fn.property : null;
          const zoomBased = referenced === null || referenced === '$zoom' || referenced === 'zoom';
          const expr = zoomBased ? convertLegacyZoomFunction(fn) : null;
          if (expr) {
            obj[key] = expr;
          } else {
            // References a data field — no automatic fix; fall back to
            // the last stop's value so the style still parses.
            const stops = Array.isArray(fn.stops) ? fn.stops : [];
            const last = Array.isArray(stops[stops.length - 1]) ? stops[stops.length - 1][1] : undefined;
            if (typeof last === 'number' || typeof last === 'string' || typeof last === 'boolean') {
              obj[key] = last;
            } else {
              delete obj[key];
            }
          }
          continue;
        }
        // 2) Keys unknown to the MapLibre spec (e.g. icon-size-scale-range)
        if (known && !known.includes(key)) {
          delete obj[key];
        }
      }
    }
  }

  return style;
}

// ── Dynamic module loading ─────────────────────────────────────────────
// maplibre-gl's export shape can vary by bundler context — handle both
// `mod.default` and a bare namespace export.
type MapLibreNS = typeof import('maplibre-gl');
let maplibrePromise: Promise<MapLibreNS> | null = null;
function loadMapLibre(): Promise<MapLibreNS> {
  if (!maplibrePromise) {
    maplibrePromise = import('maplibre-gl').then((mod) => {
      const namespace = mod as unknown as { default?: MapLibreNS } & MapLibreNS;
      const resolved = (
        typeof namespace.default?.Map === 'function' ? namespace.default : namespace
      ) as MapLibreNS;
      if (typeof resolved.Map !== 'function') {
        throw new Error('maplibre-gl module did not resolve to a usable namespace with a Map constructor');
      }
      return resolved;
    });
  }
  return maplibrePromise;
}

// ── WebGL support check ────────────────────────────────────────────────
// If unsupported we render a clear fallback message instead of a
// silent blank canvas.
function isWebGLSupported(): boolean {
  try {
    const canvas = document.createElement('canvas');
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext('webgl2') || canvas.getContext('webgl'))
    );
  } catch {
    return false;
  }
}

// ── Road-following route via Mapbox Directions API ──────────────────
// Returns [[lat,lng],...] along the road network, or null on failure
// (callers fall back to a straight line).
async function fetchDirectionsRoute(
  a: [number, number],
  b: [number, number],
): Promise<[number, number][] | null> {
  try {
    const url =
      `https://api.mapbox.com/directions/v5/mapbox/driving/` +
      `${a[1]},${a[0]};${b[1]},${b[0]}` +
      `?geometries=geojson&overview=full&access_token=${MAPBOX_TOKEN}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();
    const coords: number[][] | undefined =
      json?.routes?.[0]?.geometry?.coordinates;
    if (!coords || coords.length < 2) return null;
    return coords.map((c) => [c[1], c[0]] as [number, number]);
  } catch {
    return null;
  }
}

// ── Fit the camera to a set of [lat, lng] points ──────────────────────
function fitTo(map: MLMap, pts: [number, number][]) {
  if (pts.length < 2) return;
  let minLng = Infinity, minLat = Infinity, maxLng = -Infinity, maxLat = -Infinity;
  pts.forEach(([lat, lng]) => {
    if (lng < minLng) minLng = lng;
    if (lng > maxLng) maxLng = lng;
    if (lat < minLat) minLat = lat;
    if (lat > maxLat) maxLat = lat;
  });
  map.fitBounds([[minLng, minLat], [maxLng, maxLat]], {
    padding: 60, maxZoom: 16, duration: 800,
  });
}

// ── Marker visuals ─────────────────────────────────────────────────────
function markerSpec(
  type: string,
  color: string,
): { html: string; w: number; h: number; anchor: 'center' | 'bottom' } {
  if (type === 'rider') {
    return {
      html: `<div style="position:relative;width:36px;height:36px;display:flex;align-items:center;justify-content:center">
        <div style="position:absolute;inset:-4px;border-radius:50%;background:${color}40;animation:pulse-ring 2s ease-out infinite"></div>
        <div style="width:22px;height:22px;background:${color};border:3px solid white;border-radius:50%;box-shadow:0 3px 12px rgba(0,0,0,0.35);position:relative;z-index:2;display:flex;align-items:center;justify-content:center">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M12 2L4 7v10l8 5 8-5V7l-8-5z"/></svg>
        </div>
      </div>`,
      w: 36, h: 36, anchor: 'center',
    };
  }
  if (type === 'bike') {
    return {
      html: `<div style="position:relative;width:34px;height:34px;display:flex;align-items:center;justify-content:center">
        <div style="position:absolute;inset:-5px;border-radius:50%;background:${color}30;animation:pulse-ring 2.4s ease-out infinite"></div>
        <div style="width:24px;height:24px;background:${color};border:2.5px solid white;border-radius:50%;box-shadow:0 3px 12px rgba(0,0,0,0.35);position:relative;z-index:2;display:flex;align-items:center;justify-content:center">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="5.5" cy="17.5" r="3.5"/><circle cx="18.5" cy="17.5" r="3.5"/><circle cx="15" cy="5" r="1"/><path d="M12 17.5V14l-3-3 4-3 2 3h2"/></svg>
        </div>
      </div>`,
      w: 34, h: 34, anchor: 'center',
    };
  }
  if (type === 'pickup') {
    return {
      html: `<div style="position:relative;display:flex;flex-direction:column;align-items:center">
        <div style="width:32px;height:32px;background:#10B981;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(16,185,129,0.4)">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="white" style="transform:rotate(45deg)"><circle cx="12" cy="12" r="4"/></svg>
        </div>
        <div style="width:2px;height:8px;background:#10B981;margin-top:-2px"></div>
      </div>`,
      w: 32, h: 42, anchor: 'bottom',
    };
  }
  if (type === 'dropoff') {
    return {
      html: `<div style="position:relative;display:flex;flex-direction:column;align-items:center">
        <div style="width:32px;height:32px;background:#C41E1E;border-radius:50% 50% 50% 4px;transform:rotate(-45deg);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 14px rgba(196,30,30,0.4)">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="white" style="transform:rotate(45deg)"><path d="M5 13l4 4L19 7" stroke="white" stroke-width="3" fill="none"/></svg>
        </div>
        <div style="width:2px;height:8px;background:#C41E1E;margin-top:-2px"></div>
      </div>`,
      w: 32, h: 42, anchor: 'bottom',
    };
  }
  return {
    html: `<div style="position:relative;width:28px;height:28px;display:flex;align-items:center;justify-content:center">
      <div style="position:absolute;inset:-3px;border-radius:50%;background:${color}30;animation:pulse-ring 2s ease-out infinite"></div>
      <div style="width:16px;height:16px;background:${color};border:3px solid white;border-radius:50%;box-shadow:0 2px 10px rgba(0,0,0,0.3);position:relative;z-index:1"></div>
    </div>`,
    w: 28, h: 28, anchor: 'center',
  };
}

// ── Component ────────────────────────────────────────────────────────
export default function MapView({
  center = [5.6037, -0.187],
  zoom = 13,
  markers = [],
  route,
  secondaryRoute,
  onMapClick,
  className = 'h-[400px]',
  interactive = true,
  pinDropActive = false,
}: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MLMap | null>(null);
  const [ml, setMl] = useState<MapLibreNS | null>(null);
  const [webglOk, setWebglOk] = useState(true);
  const [styleReady, setStyleReady] = useState(false);
  const [preparedStyle, setPreparedStyle] = useState<any>(null);

  // Route geometry kept in refs; rendered as an SVG overlay so routes
  // live OUTSIDE the GL canvas (dark-mode filter can't touch them).
  const mainPtsRef = useRef<[number, number][] | null>(null);
  const mainDrawnRef = useRef<[number, number][] | null>(null);
  const secondaryPtsRef = useRef<[number, number][] | null>(null);
  const pathCasingRef = useRef<SVGPathElement>(null);
  const pathMainRef = useRef<SVGPathElement>(null);
  const pathSecondaryRef = useRef<SVGPathElement>(null);
  const animRef = useRef(0);

  const markerRefs = useRef<MLMarker[]>([]);
  const locateMarkerRef = useRef<MLMarker | null>(null);

  const onClickRef = useRef(onMapClick);
  onClickRef.current = onMapClick;

  const pinDropActiveRef = useRef(pinDropActive);
  pinDropActiveRef.current = pinDropActive;

  const dk = useThemeStore((s) => s.theme === 'dark');

  const validRoute = route?.filter(
    (r) => Array.isArray(r) && typeof r[0] === 'number' && typeof r[1] === 'number' && Number.isFinite(r[0]) && Number.isFinite(r[1]),
  );
  const routeKey = validRoute
    ? validRoute.map((r) => `${r[0].toFixed(5)},${r[1].toFixed(5)}`).join(';')
    : '';

  // Coarser key (3 decimals ≈ 110 m) so a moving rider marker doesn't
  // spam the Directions API with a refetch on every animation frame.
  const validSecondaryRoute = secondaryRoute?.filter(
    (r) => Array.isArray(r) && typeof r[0] === 'number' && typeof r[1] === 'number' && Number.isFinite(r[0]) && Number.isFinite(r[1]),
  );
  const secondaryRouteKey = validSecondaryRoute
    ? validSecondaryRoute.map((r) => `${r[0].toFixed(3)},${r[1].toFixed(3)}`).join(';')
    : '';

  // ── Load MapLibre + WebGL support check ─────────────────────────
  useEffect(() => {
    let cancelled = false;
    loadMapLibre()
      .then((mod) => {
        if (cancelled) return;
        const supportedFn = (mod as unknown as { supported?: () => boolean }).supported;
        const libCheck = typeof supportedFn === 'function' ? supportedFn() : true;
        const manualCheck = isWebGLSupported();
        const ok = libCheck || manualCheck;
        if (!ok) {
          setWebglOk(false);
          return;
        }
        setMl(mod);
      })
      .catch(() => {
        if (!cancelled) setWebglOk(false);
      });
    return () => { cancelled = true; };
  }, []);

  // ── SVG route overlay redraw (project lat/lng → screen px) ──────
  const redrawRoutes = useCallback(() => {
    const map = mapRef.current;
    if (!map) return;
    const toD = (pts: [number, number][] | null) => {
      if (!pts || pts.length < 2) return '';
      let d = '';
      for (let i = 0; i < pts.length; i++) {
        const p = map.project([pts[i][1], pts[i][0]]);
        d += `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
      }
      return d;
    };
    if (pathCasingRef.current) pathCasingRef.current.setAttribute('d', toD(mainPtsRef.current));
    if (pathMainRef.current) pathMainRef.current.setAttribute('d', toD(mainDrawnRef.current));
    if (pathSecondaryRef.current) pathSecondaryRef.current.setAttribute('d', toD(secondaryPtsRef.current));
  }, []);
  const redrawRef = useRef(redrawRoutes);
  redrawRef.current = redrawRoutes;

  // ── Fetch + sanitize the style BEFORE creating the map ──────────
  useEffect(() => {
    let cancelled = false;
    fetch(STYLE_URL)
      .then((r) => {
        if (!r.ok) throw new Error(`style fetch failed: HTTP ${r.status}`);
        return r.json();
      })
      .then((raw) => {
        if (cancelled) return;
        setPreparedStyle(sanitizeStyle(raw));
      })
      .catch((err) => {
        if (!cancelled) console.error('[MapView]', err?.message ?? err);
      });
    return () => { cancelled = true; };
  }, []);

  // ── Init map (once the module is loaded AND the style is sanitized) ──
  useEffect(() => {
    if (!ml || !preparedStyle || !containerRef.current || mapRef.current) return;
    let disposed = false;

    const map = new ml.Map({
      container: containerRef.current,
      center: [center[1], center[0]], // MapLibre uses [lng, lat]
      zoom,
      interactive,
      attributionControl: false, // we render our own compact credit line
      transformRequest,
    });
    mapRef.current = map;

    // Load the sanitized style with validation disabled so anything
    // still unrecognized is gracefully ignored rather than thrown on.
    map.setStyle(preparedStyle, { validate: false });

    // Resize handling — continuously, not just on mount
    const ro = new ResizeObserver(() => {
      if (!disposed) map.resize();
    });
    ro.observe(containerRef.current);

    // Center-pin drop mode: report the new center whenever panning stops
    const onMoveEnd = () => {
      if (pinDropActiveRef.current && onClickRef.current) {
        const c = map.getCenter();
        onClickRef.current(c.lat, c.lng);
      }
    };
    // Keep the SVG route overlay glued to the map while it moves
    const onMove = () => redrawRef.current();

    map.on('moveend', onMoveEnd);
    map.on('move', onMove);
    map.on('load', () => { if (!disposed) setStyleReady(true); });
    map.on('error', () => { if (!disposed) setStyleReady(true); });

    return () => {
      disposed = true;
      cancelAnimationFrame(animRef.current);
      ro.disconnect();
      map.off('moveend', onMoveEnd);
      map.off('move', onMove);
      markerRefs.current.forEach((m) => m.remove());
      markerRefs.current = [];
      locateMarkerRef.current?.remove();
      locateMarkerRef.current = null;
      map.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ml, preparedStyle]);

  // ── Sync markers ─────────────────────────────────────────────────
  // Rebuild only when marker CONTENT changes (callers pass fresh array
  // literals every render — identity would churn needlessly).
  const validMarkers = (markers || []).filter(
    (m) => typeof m.lat === 'number' && typeof m.lng === 'number' && Number.isFinite(m.lat) && Number.isFinite(m.lng),
  );

  const markersKey = validMarkers
    .map((m) => `${m.lat.toFixed(5)},${m.lng.toFixed(5)},${m.icon || 'pin'},${m.color || ''},${m.popup || ''}`)
    .join('|');

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ml) return;
    markerRefs.current.forEach((m) => m.remove());
    markerRefs.current = [];
    validMarkers.forEach((m) => {
      const spec = markerSpec(m.icon || 'pin', m.color || '#C41E1E');
      const el = document.createElement('div');
      el.style.width = `${spec.w}px`;
      el.style.height = `${spec.h}px`;
      el.innerHTML = spec.html;
      const marker = new ml.Marker({ element: el, anchor: spec.anchor }).setLngLat([m.lng, m.lat]);
      if (m.popup) {
        marker.setPopup(
          new ml.Popup({ closeButton: true, maxWidth: '260px' }).setHTML(
            `<div style="font-size:13px;font-weight:600;padding:4px 2px">${m.popup}</div>`,
          ),
        );
      }
      marker.addTo(map);
      markerRefs.current.push(marker);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [markersKey, ml]);

  // ── Auto-center on single marker (one location selected) ──────────
  // Ambient 'bike' markers are ignored so available riders on the map
  // don't suppress the fly-to when the user picks their first location.
  const focusKey = (() => {
    const focusable = validMarkers.filter((m) => m.icon !== 'bike');
    return focusable.length === 1 ? `${focusable[0].lat},${focusable[0].lng}` : '';
  })();

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !focusKey) return;
    // Only when exactly one focusable marker and not in pin-drop mode
    // (pin-drop mode means the user is actively panning — don't yank the view)
    if (!pinDropActiveRef.current && (!validRoute || validRoute.length < 2)) {
      const [lat, lng] = focusKey.split(',').map(Number);
      map.flyTo({ center: [lng, lat], zoom: 15, duration: 1000 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey, ml]);

  // ── Main route: Directions fetch, animated draw, auto-fit ────────
  useEffect(() => {
    cancelAnimationFrame(animRef.current);
    mainPtsRef.current = null;
    mainDrawnRef.current = null;
    redrawRoutes();

    if (!validRoute || validRoute.length < 2) return;

    const start = validRoute[0];
    const end = validRoute[validRoute.length - 1];
    let cancelled = false;

    (async () => {
      const roadPts = await fetchDirectionsRoute(start, end);
      if (cancelled) return;

      // Fall back to a straight line if the request failed
      const pts: [number, number][] = roadPts ?? [start, end];
      mainPtsRef.current = pts; // casing shows the full road immediately

      // Progressive draw of the brand line
      const batchSize = Math.max(1, Math.ceil(pts.length / 40));
      let drawn = 0;
      const step = () => {
        if (cancelled) return;
        drawn = Math.min(drawn + batchSize, pts.length);
        mainDrawnRef.current = pts.slice(0, drawn);
        redrawRoutes();
        if (drawn < pts.length) animRef.current = requestAnimationFrame(step);
      };
      animRef.current = requestAnimationFrame(step);

      // Auto-fit: only when NOT in pin-drop mode (otherwise the user
      // is actively panning and we'd yank the view away from them).
      if (!pinDropActiveRef.current && mapRef.current) {
        const all: [number, number][] = [
          ...validMarkers.map((m) => [m.lat, m.lng] as [number, number]),
          ...pts,
        ];
        fitTo(mapRef.current, all);
      }
    })();

    return () => { cancelled = true; cancelAnimationFrame(animRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeKey]);

  // ── Secondary route (dashed): e.g. rider → pickup before pickup ──
  useEffect(() => {
    secondaryPtsRef.current = null;
    redrawRoutes();

    if (!validSecondaryRoute || validSecondaryRoute.length < 2) return;

    const start = validSecondaryRoute[0];
    const end = validSecondaryRoute[validSecondaryRoute.length - 1];
    let cancelled = false;

    (async () => {
      const roadPts = await fetchDirectionsRoute(start, end);
      if (cancelled) return;
      secondaryPtsRef.current = roadPts ?? [start, end];
      redrawRoutes();
    })();

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondaryRouteKey]);

  // ── "My location" handler ────────────────────────────────────────
  const handleLocate = useCallback(() => {
    const map = mapRef.current;
    if (!map || !ml || !navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const ll: [number, number] = [pos.coords.longitude, pos.coords.latitude];
        map.flyTo({ center: ll, zoom: 15, duration: 1000 });
        if (locateMarkerRef.current) {
          locateMarkerRef.current.setLngLat(ll);
        } else {
          const el = document.createElement('div');
          el.style.width = '36px';
          el.style.height = '36px';
          el.innerHTML = `<div style="position:relative;width:36px;height:36px">
            <div style="position:absolute;inset:0;border-radius:50%;background:rgba(59,130,246,0.15)"></div>
            <div style="position:absolute;inset:11px;border-radius:50%;background:#3B82F6;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3)"></div>
          </div>`;
          locateMarkerRef.current = new ml.Marker({ element: el, anchor: 'center' })
            .setLngLat(ll)
            .addTo(map);
        }
      },
      () => {},
      { enableHighAccuracy: true },
    );
  }, [ml]);

  // ── WebGL unsupported → clear fallback ───────────────────────────
  const hasPosition = /\b(absolute|fixed|relative|sticky)\b/.test(className);

  if (!webglOk) {
    return (
      <div className={`${className} overflow-hidden ${hasPosition ? '' : 'relative'} flex items-center justify-center ${dk ? 'bg-surface-dark-3' : 'bg-gray-100'}`}>
        <div className="text-center px-6 py-4">
          <p className={cn('font-bold', dk ? 'text-white' : 'text-gray-900')}>Map unavailable</p>
          <p className={cn('text-sm mt-1', dk ? 'text-white/50' : 'text-gray-500')}>
            Your browser doesn't support WebGL, which the live map requires.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`${className} overflow-hidden ${hasPosition ? '' : 'relative'} ${dk ? 'map-dark-tiles' : ''}`}>
      {/* MapLibre canvas container.
          NOTE: must be in-flow (h-full w-full), NOT `absolute inset-0` —
          maplibre-gl.css forces `.maplibregl-map { position: relative }`
          from an unlayered rule, which beats Tailwind's layered `.absolute`
          utility and collapses an inset-0 container to zero height. */}
      <div ref={containerRef} className="h-full w-full" />

      {/* Route overlay — SVG sits ABOVE the canvas and BELOW markers,
          so the dark-mode canvas filter never touches route colors. */}
      <svg className="absolute inset-0 z-[2] pointer-events-none" width="100%" height="100%">
        <path ref={pathCasingRef} fill="none" stroke="#ffffff" strokeWidth={9} strokeOpacity={0.7} strokeLinecap="round" strokeLinejoin="round" />
        <path ref={pathSecondaryRef} fill="none" stroke="#64748B" strokeWidth={4.5} strokeOpacity={0.9} strokeDasharray="10 14" strokeLinecap="round" strokeLinejoin="round" />
        <path ref={pathMainRef} fill="none" stroke="#C41E1E" strokeWidth={5} strokeOpacity={0.95} strokeLinecap="round" strokeLinejoin="round" />
      </svg>

      {/* Loading indicator until the vector style is ready */}
      {!styleReady && (
        <div className="absolute inset-0 z-[3] flex items-center justify-center pointer-events-none">
          <div className={cn('w-10 h-10 rounded-full border-2 animate-spin',
            dk ? 'border-white/15 border-t-white/70' : 'border-gray-200 border-t-brand')} />
        </div>
      )}

      {/* Custom zoom + locate controls */}
      <div className="absolute bottom-4 right-3 z-[10] flex flex-col items-center">
        <div className="db-zoom-wrap">
          <button className="db-zoom-btn db-zoom-in" title="Zoom in" onClick={() => mapRef.current?.zoomIn()}>+</button>
          <button className="db-zoom-btn db-zoom-out" title="Zoom out" onClick={() => mapRef.current?.zoomOut()}>{'\u2212'}</button>
        </div>
        <button className="db-locate-btn" title="My location" onClick={handleLocate}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="3 11 22 2 13 21 11 13 3 11" />
          </svg>
        </button>
      </div>

      {/* Attribution credit */}
      <div className={cn('absolute bottom-0 left-0 z-[10] px-2 py-0.5 text-[10px] leading-4 rounded-tr-md',
        dk ? 'bg-black/50 text-white/60' : 'bg-white/75 text-gray-500')}>
        © <a href="https://www.mapbox.com/about/maps/" target="_blank" rel="noopener noreferrer" className="hover:underline">Mapbox</a>
        {' '}© <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer" className="hover:underline">OpenStreetMap</a>
      </div>

      {/* Center pin — visible only when pinDropActive. Pure-CSS element
          at the visual center; the map pans underneath it and moveend
          reports the new center coordinates. */}
      {pinDropActive && (
        <div className="absolute inset-0 pointer-events-none z-[500] flex items-center justify-center">
          <div className="relative flex flex-col items-center" style={{ marginTop: '-20px' }}>
            <div style={{
              width: 32, height: 32,
              background: pinDropActive ? '#C41E1E' : '#10B981',
              borderRadius: '50% 50% 50% 4px',
              transform: 'rotate(-45deg)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 4px 14px rgba(196,30,30,0.45)',
            }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="white" style={{ transform: 'rotate(45deg)' }}>
                <circle cx="12" cy="12" r="4" />
              </svg>
            </div>
            <div style={{ width: 2, height: 10, background: '#C41E1E', marginTop: -2 }} />
            <div style={{
              width: 6, height: 6, borderRadius: '50%',
              background: 'rgba(0,0,0,0.2)', marginTop: 2,
            }} />
          </div>
        </div>
      )}
    </div>
  );
}
