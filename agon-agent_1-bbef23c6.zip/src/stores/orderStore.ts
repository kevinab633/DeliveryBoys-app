import { create } from 'zustand';
import { Order, OrderStatus, OrderType, VehicleType, Location, RiderProfile } from '../lib/types';
import { generateId, formatDate } from '../lib/utils';
import { calculatePrice, calculateDistance } from '../lib/pricing';
import { getDefaultRules } from '../lib/pricing';
import { useAuthStore } from './authStore';
import { useNotificationStore } from './notificationStore';
import { fireBrowserNotification } from '../lib/browserNotify';
import { createHybridChannel, type HybridChannel } from '../lib/realtime';

// Instant orders still pending after this long are auto-cancelled.
const AUTO_CANCEL_MS = 5 * 60 * 1000;
// Scheduled orders start dispatching this long before scheduledFor.
const SCHEDULED_DISPATCH_WINDOW_MS = 30 * 60 * 1000;
// Scheduled orders still pending this long AFTER scheduledFor are cancelled.
const SCHEDULED_GRACE_MS = 15 * 60 * 1000;

// ── Notification helpers (single source of truth for lifecycle events) ──
function pushNotify(userId: string, title: string, message: string) {
  useNotificationStore.getState().addNotification({ userId, title, message, type: 'order' });
}

// Live realtime channel handle (module scope, not persisted in store state).
let orderChannel: HybridChannel | null = null;

/** Map a snake_case DB row onto the camelCase Order model. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapOrderFromDb(row: any): Order {
  return {
    id: row.id,
    customerId: row.customer_id,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    riderId: row.rider_id || undefined,
    riderName: row.rider_name || undefined,
    pickup: row.pickup,
    dropoff: row.dropoff,
    distance: row.distance,
    price: row.price,
    status: row.status,
    vehicleType: row.vehicle_type,
    packageDescription: row.package_description,
    createdAt: row.created_at,
    acceptedAt: row.accepted_at || undefined,
    pickedUpAt: row.picked_up_at || undefined,
    deliveredAt: row.delivered_at || undefined,
    riderLocation: row.rider_location || undefined,
    orderType: row.order_type,
    scheduledFor: row.scheduled_for || undefined,
    dispatchedTo: row.dispatched_to || undefined,
    cancelReason: row.cancel_reason || undefined,
  };
}

interface OrderStore {
  orders: Order[];
  _initialized: boolean;
  _subscribed: boolean;
  initFromServer: () => Promise<void>;
  subscribeRealtime: () => void;
  unsubscribeRealtime: () => void;
  createOrder: (data: {
    customerId: string;
    customerName: string;
    customerPhone: string;
    pickup: Location;
    dropoff: Location;
    vehicleType: VehicleType;
    packageDescription: string;
    orderType?: OrderType;
    scheduledFor?: number;
  }) => Promise<Order>;
  acceptOrder: (orderId: string, riderId: string, riderName: string) => Promise<boolean>;
  cancelOrder: (orderId: string) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  updateRiderLocation: (orderId: string, lat: number, lng: number) => void;
  getOrdersByCustomer: (customerId: string) => Order[];
  getOrdersByRider: (riderId: string) => Order[];
  getPendingOrders: () => Order[];
  getActiveOrders: () => Order[];
  getTotalRevenue: () => number;
  getRankedRidersForOrder: (order: Pick<Order, 'pickup'>) => RiderProfile[];
  expandOrderDispatch: (orderId: string) => void;
  sweepExpiredOrders: () => void;
}

export const useOrderStore = create<OrderStore>()((set, get) => ({
  orders: [],
  _initialized: false,
  _subscribed: false,

  // ── Fetch all orders from the server on startup ──────────────────
  initFromServer: async () => {
    if (get()._initialized) return;
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        set({ orders: data, _initialized: true });
      } else {
        set({ _initialized: true });
      }
    } catch (err) {
      console.error('[orderStore] Failed to fetch orders:', err);
      set({ _initialized: true });
    }
  },

  // ── Subscribe to Supabase Realtime for live cross-device sync ────
  // Listens on BOTH the native postgres_changes WAL stream and the
  // application broadcast channel; see src/lib/realtime.ts. Every handler
  // below is idempotent so receiving the same change twice is harmless.
  subscribeRealtime: () => {
    if (get()._subscribed) return;
    set({ _subscribed: true });

    orderChannel = createHybridChannel({
      name: 'orders',
      table: 'orders',
      onChange: ({ type, row, oldId }) => {
        if (type === 'DELETE') {
          if (!oldId) return;
          set(s => ({ orders: s.orders.filter(o => o.id !== oldId) }));
          return;
        }

        if (!row) return;
        const incoming = mapOrderFromDb(row);

        set(s => {
          const exists = s.orders.some(o => o.id === incoming.id);
          // INSERT for a row we already added optimistically -> no-op.
          if (exists && type === 'INSERT') return s;
          if (exists) {
            return { orders: s.orders.map(o => (o.id === incoming.id ? incoming : o)) };
          }
          // Unknown row (INSERT, or an UPDATE whose INSERT we missed).
          return { orders: [incoming, ...s.orders] };
        });
      },
    });
  },

  unsubscribeRealtime: () => {
    if (orderChannel) {
      orderChannel.close();
      orderChannel = null;
    }
    set({ _subscribed: false });
  },

  // ── Create order: compute price locally, POST to API, optimistic update ──
  createOrder: async (data) => {
    const distance = calculateDistance(data.pickup.lat, data.pickup.lng, data.dropoff.lat, data.dropoff.lng);
    const { price } = calculatePrice(distance, data.vehicleType, getDefaultRules());
    const orderType: OrderType = data.orderType || 'instant';

    let dispatchedTo: string[] = [];
    if (orderType === 'instant') {
      const ranked = get().getRankedRidersForOrder({ pickup: data.pickup });
      dispatchedTo = ranked.length > 0 ? [ranked[0].id] : [];
    }

    const order: Order = {
      id: `ORD-${generateId().toUpperCase().slice(0, 6)}`,
      customerId: data.customerId,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      pickup: data.pickup,
      dropoff: data.dropoff,
      vehicleType: data.vehicleType,
      packageDescription: data.packageDescription,
      distance,
      price,
      status: 'pending',
      orderType,
      scheduledFor: orderType === 'scheduled' ? data.scheduledFor : undefined,
      createdAt: Date.now(),
      dispatchedTo,
    };

    // Optimistic local update
    set(s => ({ orders: [order, ...s.orders] }));

    // Persist to server (Realtime will broadcast to other clients)
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', order }),
      });
    } catch (err) {
      console.error('[orderStore] createOrder API error:', err);
    }

    // Lifecycle notification: order created
    if (orderType === 'scheduled') {
      pushNotify(data.customerId, 'Order Scheduled!', `Order ${order.id} is scheduled for ${formatDate(order.scheduledFor!)}.`);
      fireBrowserNotification('Order Scheduled', `Order ${order.id} is scheduled for ${formatDate(order.scheduledFor!)}.`);
    } else {
      pushNotify(data.customerId, 'Order Placed!', `Order ${order.id} has been placed. Waiting for a rider.`);
      fireBrowserNotification('Order Placed', `Order ${order.id} has been placed. Waiting for a rider.`);
    }
    return order;
  },

  // ── Accept order: race-condition safe via server check ──────────
  acceptOrder: async (orderId, riderId, riderName) => {
    const order = get().orders.find(o => o.id === orderId);
    if (!order || order.status !== 'pending') return false;

    // Optimistic local update
    set(s => ({
      orders: s.orders.map(o => o.id === orderId ? { ...o, riderId, riderName, status: 'accepted' as OrderStatus, acceptedAt: Date.now() } : o),
    }));

    // Server-side race-condition guard
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'accept', orderId, riderId, riderName }),
      });
      const result = await res.json();
      if (!result.ok) {
        // Revert: another rider got it first
        set(s => ({
          orders: s.orders.map(o => o.id === orderId ? { ...o, riderId: undefined, riderName: undefined, status: 'pending' as OrderStatus, acceptedAt: undefined } : o),
        }));
        return false;
      }
    } catch (err) {
      console.error('[orderStore] acceptOrder API error:', err);
      return false;
    }

    // Lifecycle notifications: accepted
    const riderProfile = useAuthStore.getState().allUsers.find(u => u.id === riderId);
    const phone = riderProfile && 'phone' in riderProfile && riderProfile.phone
      ? ` Rider phone: ${riderProfile.phone}.`
      : '';
    pushNotify(order.customerId, 'Rider Assigned!', `A rider is on the way to pickup — ${riderName} accepted your order ${orderId}.${phone}`);
    pushNotify(riderId, 'Order Accepted', `You accepted order ${orderId}. Head to the pickup point.`);
    fireBrowserNotification('Rider Assigned', `${riderName} accepted order ${orderId} — on the way to pickup.`);
    return true;
  },

  cancelOrder: (orderId) => {
    const order = get().orders.find(o => o.id === orderId);
    set(s => ({
      orders: s.orders.map(o => o.id === orderId && o.status === 'pending' ? { ...o, status: 'cancelled' as OrderStatus } : o),
    }));

    // Persist to server
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'cancel', orderId, cancelReason: 'user_cancelled' }),
    }).catch(err => console.error('[orderStore] cancelOrder API error:', err));

    if (order && order.status === 'pending') {
      pushNotify(order.customerId, 'Order Cancelled', `Your order ${orderId} was cancelled.`);
      if (order.riderId) {
        pushNotify(order.riderId, 'Order Cancelled', `Order ${orderId} was cancelled by the customer.`);
      }
      fireBrowserNotification('Order Cancelled', `Order ${orderId} was cancelled.`);
    }
  },

  updateOrderStatus: (orderId, status) => {
    const order = get().orders.find(o => o.id === orderId);
    set(s => ({
      orders: s.orders.map(o => {
        if (o.id !== orderId) return o;
        const updates: Partial<Order> = { status };
        if (status === 'picked_up') updates.pickedUpAt = Date.now();
        if (status === 'delivered') updates.deliveredAt = Date.now();
        return { ...o, ...updates };
      }),
    }));

    // Persist to server
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_status', orderId, status }),
    }).catch(err => console.error('[orderStore] updateOrderStatus API error:', err));

    if (!order) return;

    if (status === 'picked_up') {
      pushNotify(order.customerId, 'Package Picked Up', `Your order ${orderId} has been picked up and is on its way.`);
      if (order.riderId) pushNotify(order.riderId, 'Picked Up', `You picked up order ${orderId}. Safe travels!`);
      fireBrowserNotification('Package Picked Up', `Order ${orderId} has been picked up.`);
    } else if (status === 'in_transit') {
      pushNotify(order.customerId, 'In Transit', `Your order ${orderId} is in transit — track it live on the map.`);
      if (order.riderId) pushNotify(order.riderId, 'Delivery Started', `Order ${orderId} is in transit to the drop-off.`);
      fireBrowserNotification('In Transit', `Order ${orderId} is on its way.`);
    } else if (status === 'delivered') {
      pushNotify(order.customerId, 'Delivered \ud83c\udf89', `Your order ${orderId} has been delivered. Thank you for using Delivery Boys!`);
      if (order.riderId) pushNotify(order.riderId, 'Delivered', `Order ${orderId} delivered. Great job!`);
      fireBrowserNotification('Delivered \ud83c\udf89', `Order ${orderId} has been delivered.`);
    } else if (status === 'cancelled') {
      pushNotify(order.customerId, 'Order Cancelled', `Your order ${orderId} was cancelled.`);
      if (order.riderId) pushNotify(order.riderId, 'Order Cancelled', `Order ${orderId} was cancelled.`);
      fireBrowserNotification('Order Cancelled', `Order ${orderId} was cancelled.`);
    }
  },

  updateRiderLocation: (orderId, lat, lng) => {
    set(s => ({
      orders: s.orders.map(o => o.id === orderId ? { ...o, riderLocation: { lat, lng } } : o),
    }));
    // Persist to server (fire-and-forget for performance)
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_rider_location', orderId, lat, lng }),
    }).catch(() => {});
  },

  // ── Staged dispatch helpers ────────────────────────────────────────
  getRankedRidersForOrder: (order) => {
    const riders = useAuthStore.getState().allUsers.filter(
      (u): u is RiderProfile => u.role === 'rider',
    );
    return riders
      .filter(r => r.availability === 'online' && r.location)
      .map(r => ({
        rider: r,
        dist: calculateDistance(r.location!.lat, r.location!.lng, order.pickup.lat, order.pickup.lng),
      }))
      .sort((a, b) => a.dist - b.dist)
      .map(x => x.rider);
  },

  expandOrderDispatch: (orderId) => {
    const order = get().orders.find(o => o.id === orderId);
    if (!order || order.status !== 'pending') return;
    const current = order.dispatchedTo || [];
    const ranked = get().getRankedRidersForOrder(order);
    const candidates = ranked.filter(r => !current.includes(r.id)).slice(0, 2).map(r => r.id);
    if (candidates.length === 0) return;

    const newDispatched = [...current, ...candidates.filter(id => !current.includes(id))];
    set(s => ({
      orders: s.orders.map(o => {
        if (o.id !== orderId || o.status !== 'pending') return o;
        return { ...o, dispatchedTo: newDispatched };
      }),
    }));

    // Persist to server
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_dispatched_to', orderId, dispatchedTo: newDispatched }),
    }).catch(() => {});
  },

  sweepExpiredOrders: () => {
    const now = Date.now();
    const ordersNow = get().orders;
    const toCancel: { id: string; customerId: string; reason: string; scheduled: boolean }[] = [];

    for (const o of ordersNow) {
      if (o.status !== 'pending') continue;
      const scheduled = (o.orderType || 'instant') === 'scheduled';

      if (!scheduled) {
        if (now - o.createdAt > AUTO_CANCEL_MS) {
          toCancel.push({ id: o.id, customerId: o.customerId, reason: 'no_riders_available', scheduled: false });
        }
        continue;
      }

      const when = o.scheduledFor ?? o.createdAt;

      if (now >= when - SCHEDULED_DISPATCH_WINDOW_MS && now <= when + SCHEDULED_GRACE_MS && (o.dispatchedTo || []).length === 0) {
        const ranked = get().getRankedRidersForOrder(o);
        if (ranked.length > 0) {
          const firstId = ranked[0].id;
          const newDispatched = [firstId];
          set(s => ({
            orders: s.orders.map(x =>
              x.id === o.id && x.status === 'pending' ? { ...x, dispatchedTo: newDispatched } : x,
            ),
          }));
          // Persist dispatch
          fetch('/api/orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'update_dispatched_to', orderId: o.id, dispatchedTo: newDispatched }),
          }).catch(() => {});

          const onlineRiders = useAuthStore.getState().allUsers.filter(
            u => u.role === 'rider' && (u as { availability?: string }).availability === 'online',
          );
          onlineRiders.forEach(r => {
            pushNotify(r.id, 'Scheduled Delivery Coming Up', `Order ${o.id} is due at ${formatDate(when)} — ${o.pickup.address} → ${o.dropoff.address}.`);
          });
          fireBrowserNotification('Scheduled Delivery Coming Up', `Order ${o.id} is due at ${formatDate(when)}.`);
        }
      }

      if (now > when + SCHEDULED_GRACE_MS) {
        toCancel.push({ id: o.id, customerId: o.customerId, reason: 'no_riders_available_scheduled', scheduled: true });
      }
    }

    if (toCancel.length === 0) return;

    const ids = new Set(toCancel.map(c => c.id));
    const reasonById = new Map(toCancel.map(c => [c.id, c.reason]));
    set(s => ({
      orders: s.orders.map(o =>
        ids.has(o.id) && o.status === 'pending'
          ? { ...o, status: 'cancelled' as OrderStatus, cancelReason: reasonById.get(o.id) }
          : o,
      ),
    }));

    // Persist bulk cancellation to server
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'bulk_cancel',
        cancellations: toCancel.map(c => ({ id: c.id, cancelReason: c.reason })),
      }),
    }).catch(() => {});

    toCancel.forEach(c => {
      const title = c.scheduled ? 'Scheduled Delivery Unfilled' : 'No Riders Available';
      const msg = c.scheduled
        ? `We couldn't find a rider for your scheduled delivery ${c.id} — please rebook or try again.`
        : `No riders were available for order ${c.id}. Please try again shortly.`;
      pushNotify(c.customerId, title, msg);
      fireBrowserNotification(title, msg);
    });
  },

  getOrdersByCustomer: (customerId) => get().orders.filter(o => o.customerId === customerId),
  getOrdersByRider: (riderId) => get().orders.filter(o => o.riderId === riderId),
  getPendingOrders: () => get().orders.filter(o => o.status === 'pending'),
  getActiveOrders: () => get().orders.filter(o => ['accepted', 'picked_up', 'in_transit'].includes(o.status)),
  getTotalRevenue: () => get().orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.price, 0),
}));
