import type { RealtimeChannel } from '@supabase/supabase-js';
import supabaseClient from './supabase';

/**
 * Hybrid realtime transport.
 *
 * Two independent channels are used on purpose:
 *
 *  1. `postgres_changes` — the native Supabase WAL stream. This only emits
 *     rows once the table has been added to the `supabase_realtime`
 *     publication (see supabase/enable-realtime.sql). Until then the channel
 *     still reports SUBSCRIBED but silently delivers nothing.
 *
 *  2. `broadcast` — an application-level fan-out pushed by the API routes
 *     after every successful write. This requires no replication setup and
 *     no RLS read access, so live sync works immediately.
 *
 * They are deliberately kept on SEPARATE channels: if the postgres_changes
 * binding errors (table not in the publication), it must not take the
 * broadcast channel down with it.
 *
 * Both paths funnel into the same reducer, and every consumer de-duplicates
 * by row id, so double delivery is harmless once replication is enabled.
 */

export type ChangeType = 'INSERT' | 'UPDATE' | 'DELETE';

export interface RowChange<T> {
  type: ChangeType;
  row?: T;
  oldId?: string;
}

export interface HybridChannelOptions<T> {
  /** Logical name, e.g. "orders". Used to derive channel topics. */
  name: string;
  /** Postgres table name in the public schema. */
  table: string;
  /** Called for every change from either transport. */
  onChange: (change: RowChange<T>) => void;
}

export interface HybridChannel {
  status: () => string;
  close: () => void;
}

const MAX_BACKOFF_MS = 30_000;

function log(scope: string, ...args: unknown[]) {
  if (import.meta.env.DEV) console.info(`[realtime:${scope}]`, ...args);
}

/**
 * Subscribe with automatic, backed-off re-subscription so a transient
 * CHANNEL_ERROR / TIMED_OUT does not permanently kill live updates.
 */
function resilientSubscribe(
  scope: string,
  build: () => RealtimeChannel,
  onStatus: (s: string) => void,
): { close: () => void } {
  let channel: RealtimeChannel | null = null;
  let attempt = 0;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let closed = false;

  const connect = () => {
    if (closed) return;
    channel = build();
    channel.subscribe((status: string) => {
      onStatus(status);
      log(scope, status);

      if (status === 'SUBSCRIBED') {
        attempt = 0;
        return;
      }

      if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
        if (closed) return;
        // Tear the old channel down before retrying, otherwise the client
        // accumulates dead channels and keeps re-emitting CHANNEL_ERROR.
        const dead = channel;
        channel = null;
        if (dead) supabaseClient.removeChannel(dead);

        const delay = Math.min(1000 * 2 ** attempt, MAX_BACKOFF_MS);
        attempt += 1;
        if (timer) clearTimeout(timer);
        timer = setTimeout(connect, delay);
      }
    });
  };

  connect();

  return {
    close: () => {
      closed = true;
      if (timer) clearTimeout(timer);
      if (channel) supabaseClient.removeChannel(channel);
      channel = null;
    },
  };
}

export function createHybridChannel<T>({ name, table, onChange }: HybridChannelOptions<T>): HybridChannel {
  let pgStatus = 'INIT';
  let bcStatus = 'INIT';

  // ── 1. Native WAL replication (best effort) ──────────────────────
  const pg = resilientSubscribe(
    `${name}:postgres_changes`,
    () =>
      supabaseClient.channel(`${name}-pg`).on(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        'postgres_changes' as any,
        { event: '*', schema: 'public', table },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (payload: any) => {
          if (payload.eventType === 'INSERT') onChange({ type: 'INSERT', row: payload.new as T });
          else if (payload.eventType === 'UPDATE') onChange({ type: 'UPDATE', row: payload.new as T });
          else if (payload.eventType === 'DELETE') onChange({ type: 'DELETE', oldId: payload.old?.id });
        },
      ),
    s => { pgStatus = s; },
  );

  // ── 2. Application broadcast (always available) ──────────────────
  const bc = resilientSubscribe(
    `${name}:broadcast`,
    () =>
      supabaseClient
        .channel(`${name}-sync`, { config: { broadcast: { self: true } } })
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .on('broadcast', { event: 'change' }, (msg: any) => {
          const p = msg?.payload;
          if (!p || !p.type) return;
          onChange({ type: p.type as ChangeType, row: p.row as T, oldId: p.oldId });
        }),
    s => { bcStatus = s; },
  );

  return {
    status: () => `pg=${pgStatus} broadcast=${bcStatus}`,
    close: () => { pg.close(); bc.close(); },
  };
}
