// Server-side Realtime broadcast helper.
//
// Pushes a change event to every subscribed client over Supabase Realtime
// using the HTTP broadcast endpoint. This deliberately does NOT depend on
// logical replication (`supabase_realtime` publication) or on RLS read
// access, so live sync works even when the tables have not been added to
// the publication yet.

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

/**
 * @param {string} topic  Channel topic, e.g. "orders-sync"
 * @param {'INSERT'|'UPDATE'|'DELETE'} type
 * @param {object} payload  { row } or { oldId }
 */
export async function broadcastChange(topic, type, payload) {
  if (!SUPABASE_URL || !SERVICE_KEY) return;
  try {
    await fetch(`${SUPABASE_URL}/realtime/v1/api/broadcast`, {
      method: 'POST',
      headers: {
        apikey: SERVICE_KEY,
        Authorization: `Bearer ${SERVICE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages: [{ topic, event: 'change', payload: { type, ...payload } }],
      }),
    });
  } catch (err) {
    // Never let a broadcast failure break the write path.
    console.error('[broadcast] failed:', err.message);
  }
}
