import supabase from './db-client.js';
import { broadcastChange } from './_broadcast.js';

const TOPIC = 'orders-sync';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      // Map snake_case DB columns to camelCase for frontend
      const mapped = (data || []).map(mapOrderFromDb);
      return res.status(200).json(mapped);
    }

    if (req.method === 'POST') {
      const { action } = req.body;

      if (action === 'create') {
        const o = req.body.order;
        const row = mapOrderToDb(o);
        const { data, error } = await supabase
          .from('orders')
          .insert(row)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'INSERT', { row: data });
        return res.status(201).json(mapOrderFromDb(data));
      }

      if (action === 'accept') {
        const { orderId, riderId, riderName } = req.body;
        // Race-condition guard: only accept if still pending
        const { data: existing } = await supabase
          .from('orders')
          .select('status')
          .eq('id', orderId)
          .single();
        if (!existing || existing.status !== 'pending') {
          return res.status(200).json({ ok: false, reason: 'already_taken' });
        }
        const { data, error } = await supabase
          .from('orders')
          .update({
            rider_id: riderId,
            rider_name: riderName,
            status: 'accepted',
            accepted_at: Date.now(),
          })
          .eq('id', orderId)
          .eq('status', 'pending')
          .select()
          .single();
        if (error) throw error;
        if (!data) return res.status(200).json({ ok: false, reason: 'already_taken' });
        await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json({ ok: true, order: mapOrderFromDb(data) });
      }

      if (action === 'update_status') {
        const { orderId, status } = req.body;
        const updates = { status };
        if (status === 'picked_up') updates.picked_up_at = Date.now();
        if (status === 'delivered') updates.delivered_at = Date.now();
        const { data, error } = await supabase
          .from('orders')
          .update(updates)
          .eq('id', orderId)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(mapOrderFromDb(data));
      }

      if (action === 'cancel') {
        const { orderId, cancelReason } = req.body;
        const { data, error } = await supabase
          .from('orders')
          .update({ status: 'cancelled', cancel_reason: cancelReason || 'user_cancelled' })
          .eq('id', orderId)
          .eq('status', 'pending')
          .select()
          .single();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapOrderFromDb(data) : { ok: false });
      }

      if (action === 'update_rider_location') {
        const { orderId, lat, lng } = req.body;
        const { data, error } = await supabase
          .from('orders')
          .update({ rider_location: { lat, lng } })
          .eq('id', orderId)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(mapOrderFromDb(data));
      }

      if (action === 'update_dispatched_to') {
        const { orderId, dispatchedTo } = req.body;
        const { data, error } = await supabase
          .from('orders')
          .update({ dispatched_to: dispatchedTo })
          .eq('id', orderId)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(mapOrderFromDb(data));
      }

      if (action === 'bulk_cancel') {
        const { cancellations } = req.body;
        // cancellations: [{id, cancelReason}]
        for (const c of cancellations) {
          const { data: row } = await supabase
            .from('orders')
            .update({ status: 'cancelled', cancel_reason: c.cancelReason })
            .eq('id', c.id)
            .eq('status', 'pending')
            .select()
            .maybeSingle();
          if (row) await broadcastChange(TOPIC, 'UPDATE', { row });
        }
        return res.status(200).json({ ok: true });
      }

      return res.status(400).json({ error: 'Unknown action' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /orders error:', err);
    res.status(500).json({ error: err.message });
  }
}

// ── Column mapping helpers ──────────────────────────────────────────
function mapOrderToDb(o) {
  return {
    id: o.id,
    customer_id: o.customerId,
    customer_name: o.customerName,
    customer_phone: o.customerPhone,
    rider_id: o.riderId || null,
    rider_name: o.riderName || null,
    pickup: o.pickup,
    dropoff: o.dropoff,
    distance: o.distance,
    price: o.price,
    status: o.status,
    vehicle_type: o.vehicleType,
    package_description: o.packageDescription,
    created_at: o.createdAt,
    accepted_at: o.acceptedAt || null,
    picked_up_at: o.pickedUpAt || null,
    delivered_at: o.deliveredAt || null,
    rider_location: o.riderLocation || null,
    order_type: o.orderType,
    scheduled_for: o.scheduledFor || null,
    dispatched_to: o.dispatchedTo || null,
    cancel_reason: o.cancelReason || null,
  };
}

function mapOrderFromDb(row) {
  return {
    id: row.id,
    customerId: row.customer_id,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    riderId: row.rider_id || undefined,
    riderName: row.rider_name || undefined,
    pickup: row.pickup,
    dropoff: row.dropoff,
    distance: row.distance,
    price: row.price,
    status: row.status,
    vehicleType: row.vehicle_type,
    packageDescription: row.package_description,
    createdAt: row.created_at,
    acceptedAt: row.accepted_at || undefined,
    pickedUpAt: row.picked_up_at || undefined,
    deliveredAt: row.delivered_at || undefined,
    riderLocation: row.rider_location || undefined,
    orderType: row.order_type,
    scheduledFor: row.scheduled_for || undefined,
    dispatchedTo: row.dispatched_to || undefined,
    cancelReason: row.cancel_reason || undefined,
  };
}
