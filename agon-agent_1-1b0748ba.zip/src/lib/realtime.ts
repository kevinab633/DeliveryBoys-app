import type { RealtimeChannel } from '@supabase/supabase-js';
import supabaseClient from './supabase';
import { useDebugStore } from './debugStore';

export type ChangeType = 'INSERT' | 'UPDATE' | 'DELETE';

export interface RowChange<T> {
  type: ChangeType;
  row?: T;
  oldId?: string;
}

export interface HybridChannelOptions<T> {
  name: string;
  table: string;
  onChange: (change: RowChange<T>) => void;
}

export interface HybridChannel {
  status: () => string;
  close: () => void;
}

const MAX_BACKOFF_MS = 30_000;

function log(scope: string, ...args: unknown[]) {
  if (import.meta.env.DEV) console.info(`[realtime:${scope}]`, ...args);
}

function resilientSubscribe(
  scope: string,
  build: () => RealtimeChannel,
  onStatus: (s: string) => void,
): { close: () => void } {
  let channel: RealtimeChannel | null = null;
  let attempt = 0;
  let timer: ReturnType<typeof setTimeout> | null = null;
  let closed = false;

  const connect = () => {
    if (closed) return;
    channel = build();
    channel.subscribe((status: string) => {
      onStatus(status);
      log(scope, status);
      useDebugStore.getState().addLog(`Channel ${scope} status: ${status}`, status === 'SUBSCRIBED' ? 'info' : 'error');

      if (status === 'SUBSCRIBED') {
        attempt = 0;
        return;
      }

      if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
        if (closed) return;
        const dead = channel;
        channel = null;
        if (dead) supabaseClient.removeChannel(dead);

        const delay = Math.min(1000 * 2 ** attempt, MAX_BACKOFF_MS);
        attempt += 1;
        if (timer) clearTimeout(timer);
        timer = setTimeout(connect, delay);
      }
    });
  };

  connect();

  return {
    close: () => {
      closed = true;
      if (timer) clearTimeout(timer);
      if (channel) supabaseClient.removeChannel(channel);
      channel = null;
    },
  };
}

export function createHybridChannel<T>({ name, table, onChange }: HybridChannelOptions<T>): HybridChannel {
  let pgStatus = 'INIT';
  let bcStatus = 'INIT';

  // 1. Native WAL replication
  const pg = resilientSubscribe(
    `${name}:postgres_changes`,
    () =>
      supabaseClient.channel(`${name}-pg`).on(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        'postgres_changes' as any,
        { event: '*', schema: 'public', table },
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (payload: any) => {
          const rowId = payload.new?.id || payload.old?.id || 'unknown';
          const rowStatus = payload.new?.status || '';
          useDebugStore.getState().addLog(`[PG-WAL-RECEIVE] ${payload.eventType} table:${table} id:${String(rowId).slice(0, 8)}... status:${rowStatus}`, 'receive');

          if (payload.eventType === 'INSERT') onChange({ type: 'INSERT', row: payload.new as T });
          else if (payload.eventType === 'UPDATE') onChange({ type: 'UPDATE', row: payload.new as T });
          else if (payload.eventType === 'DELETE') onChange({ type: 'DELETE', oldId: payload.old?.id });
        },
      ),
    s => { pgStatus = s; },
  );

  // 2. Application broadcast
  const bc = resilientSubscribe(
    `${name}:broadcast`,
    () =>
      supabaseClient
        .channel(`${name}-sync`, { config: { broadcast: { self: true } } })
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .on('broadcast', { event: 'change' }, (msg: any) => {
          const p = msg?.payload;
          if (!p || !p.type) return;
          const rowId = p.row?.id || p.oldId || 'unknown';
          const rowStatus = p.row?.status || '';
          useDebugStore.getState().addLog(`[BROADCAST-RECEIVE] ${p.type} channel:${name}-sync id:${String(rowId).slice(0, 8)}... status:${rowStatus}`, 'receive');

          onChange({ type: p.type as ChangeType, row: p.row as T, oldId: p.oldId });
        }),
    s => { bcStatus = s; },
  );

  return {
    status: () => `pg=${pgStatus} broadcast=${bcStatus}`,
    close: () => { pg.close(); bc.close(); },
  };
}
