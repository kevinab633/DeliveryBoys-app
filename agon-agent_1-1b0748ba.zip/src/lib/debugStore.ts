import { create } from 'zustand';

export interface DebugLog {
  id: string;
  time: string;
  type: 'info' | 'broadcast' | 'receive' | 'error';
  message: string;
}

interface DebugStore {
  logs: DebugLog[];
  visible: boolean;
  toggleVisible: () => void;
  addLog: (message: string, type?: 'info' | 'broadcast' | 'receive' | 'error') => void;
  clearLogs: () => void;
}

export const useDebugStore = create<DebugStore>((set) => ({
  logs: [],
  visible: true,
  toggleVisible: () => set(s => ({ visible: !s.visible })),
  addLog: (message, type = 'info') => {
    const time = new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    console.log(`[DEBUG-BANNER] [${time}] [${type.toUpperCase()}] ${message}`);
    set(s => ({
      logs: [{ id: Math.random().toString(36).substring(2, 9), time, type, message }, ...s.logs].slice(0, 20)
    }));
  },
  clearLogs: () => set({ logs: [] }),
}));
