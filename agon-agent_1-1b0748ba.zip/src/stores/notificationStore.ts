import { create } from 'zustand';
import { Notification } from '../lib/types';
import { generateId } from '../lib/utils';
import { createHybridChannel, type HybridChannel } from '../lib/realtime';

// Live realtime channel handle (module scope, not persisted in store state).
let notifChannel: HybridChannel | null = null;

/** Map a snake_case DB row onto the camelCase Notification model. */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapNotifFromDb(row: any): Notification {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    message: row.message,
    type: row.type,
    read: row.read,
    createdAt: row.created_at,
  };
}

interface NotificationStore {
  notifications: Notification[];
  _initialized: boolean;
  _subscribed: boolean;
  initFromServer: (userId?: string) => Promise<void>;
  subscribeRealtime: () => void;
  unsubscribeRealtime: () => void;
  addNotification: (n: Omit<Notification, 'id' | 'read' | 'createdAt'>) => void;
  markRead: (id: string) => void;
  markAllRead: (userId: string) => void;
  getUnread: (userId: string) => Notification[];
  getUserNotifications: (userId: string) => Notification[];
}

export const useNotificationStore = create<NotificationStore>()((set, get) => ({
  notifications: [],
  _initialized: false,
  _subscribed: false,

  initFromServer: async (userId?: string) => {
    try {
      const url = userId ? `/api/notifications?userId=${userId}` : '/api/notifications';
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        set({ notifications: data, _initialized: true });
      } else {
        set({ _initialized: true });
      }
    } catch (err) {
      console.error('[notificationStore] Failed to fetch notifications:', err);
      set({ _initialized: true });
    }
  },

  // Listens on BOTH the native postgres_changes WAL stream and the
  // application broadcast channel; see src/lib/realtime.ts.
  subscribeRealtime: () => {
    if (get()._subscribed) return;
    set({ _subscribed: true });

    notifChannel = createHybridChannel({
      name: 'notifications',
      table: 'notifications',
      onChange: ({ type, row, oldId }) => {
        if (type === 'DELETE') {
          if (!oldId) return;
          set(s => ({ notifications: s.notifications.filter(n => n.id !== oldId) }));
          return;
        }

        if (!row) return;
        const incoming = mapNotifFromDb(row);

        set(s => {
          const exists = s.notifications.some(n => n.id === incoming.id);
          if (exists && type === 'INSERT') return s;
          if (exists) {
            return { notifications: s.notifications.map(n => (n.id === incoming.id ? incoming : n)) };
          }
          return { notifications: [incoming, ...s.notifications] };
        });
      },
    });
  },

  unsubscribeRealtime: () => {
    if (notifChannel) {
      notifChannel.close();
      notifChannel = null;
    }
    set({ _subscribed: false });
  },

  addNotification: (n) => {
    const notification: Notification = {
      ...n,
      id: generateId(),
      read: false,
      createdAt: Date.now(),
    };
    // Optimistic local update
    set(s => ({
      notifications: [notification, ...s.notifications],
    }));
    // Persist to server (Realtime broadcasts to other clients)
    fetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'create', notification }),
    }).catch(err => console.error('[notificationStore] addNotification API error:', err));
  },

  markRead: (id) => {
    set(s => ({
      notifications: s.notifications.map(n => n.id === id ? { ...n, read: true } : n),
    }));
    fetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'mark_read', id }),
    }).catch(() => {});
  },

  markAllRead: (userId) => {
    set(s => ({
      notifications: s.notifications.map(n => n.userId === userId ? { ...n, read: true } : n),
    }));
    fetch('/api/notifications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'mark_all_read', userId }),
    }).catch(() => {});
  },

  getUnread: (userId) => get().notifications.filter(n => n.userId === userId && !n.read),
  getUserNotifications: (userId) => get().notifications.filter(n => n.userId === userId),
}));
