import { create } from 'zustand';
import { Order, OrderStatus, OrderType, VehicleType, Location, RiderProfile } from '../lib/types';
import { generateId, formatDate } from '../lib/utils';
import { calculatePrice, calculateDistance } from '../lib/pricing';
import { getDefaultRules } from '../lib/pricing';
import { useAuthStore } from './authStore';
import { useNotificationStore } from './notificationStore';
import { useDebugStore } from '../lib/debugStore';
import { fireBrowserNotification } from '../lib/browserNotify';
import { createHybridChannel, type HybridChannel } from '../lib/realtime';

const AUTO_CANCEL_MS = 5 * 60 * 1000;
const SCHEDULED_DISPATCH_WINDOW_MS = 30 * 60 * 1000;
const SCHEDULED_GRACE_MS = 15 * 60 * 1000;

function pushNotify(userId: string, title: string, message: string) {
  useNotificationStore.getState().addNotification({ userId, title, message, type: 'order' });
}

let orderChannel: HybridChannel | null = null;

// Safe row-to-Order mapper with zero throw guarantee
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapOrderFromDb(row: any): Order {
  if (!row) throw new Error('Cannot map null or undefined DB row');

  let pickup = row.pickup;
  if (typeof pickup === 'string') {
    try { pickup = JSON.parse(pickup); } catch { pickup = { lat: 0, lng: 0, address: pickup }; }
  }
  pickup = pickup || { lat: 0, lng: 0, address: 'Unknown Pickup' };

  let dropoff = row.dropoff;
  if (typeof dropoff === 'string') {
    try { dropoff = JSON.parse(dropoff); } catch { dropoff = { lat: 0, lng: 0, address: dropoff }; }
  }
  dropoff = dropoff || { lat: 0, lng: 0, address: 'Unknown Dropoff' };

  const customerName = pickup.customerName || row.customer_name || 'Customer';
  const customerPhone = pickup.customerPhone || row.customer_phone || '';
  const distance = pickup.distance || row.distance || 0;

  const createdAt = typeof row.created_at === 'number'
    ? row.created_at
    : row.created_at ? new Date(row.created_at).getTime() : Date.now();

  return {
    id: row.id,
    customerId: row.customer_id || '',
    customerName,
    customerPhone,
    riderId: row.rider_id || undefined,
    riderName: row.rider_name || undefined,
    pickup,
    dropoff,
    distance,
    price: row.price || 0,
    status: row.status || 'pending',
    vehicleType: row.vehicle_type || 'motorcycle',
    packageDescription: row.package_description || undefined,
    createdAt,
    acceptedAt: row.accepted_at ? (typeof row.accepted_at === 'number' ? row.accepted_at : new Date(row.accepted_at).getTime()) : undefined,
    pickedUpAt: row.picked_up_at ? (typeof row.picked_up_at === 'number' ? row.picked_up_at : new Date(row.picked_up_at).getTime()) : undefined,
    deliveredAt: row.delivered_at ? (typeof row.delivered_at === 'number' ? row.delivered_at : new Date(row.delivered_at).getTime()) : undefined,
    riderLocation: row.rider_location || undefined,
    orderType: row.order_type || 'instant',
    scheduledFor: row.scheduled_for || undefined,
    dispatchedTo: row.dispatched_to || undefined,
    cancelReason: row.cancel_reason || undefined,
  };
}

interface OrderStore {
  orders: Order[];
  _initialized: boolean;
  _subscribed: boolean;
  initFromServer: () => Promise<void>;
  subscribeRealtime: () => void;
  unsubscribeRealtime: () => void;
  createOrder: (data: {
    id?: string;
    customerId: string;
    customerName: string;
    customerPhone: string;
    pickup: Location;
    dropoff: Location;
    vehicleType: VehicleType;
    packageDescription: string;
    orderType?: OrderType;
    scheduledFor?: number;
  }) => Promise<Order>;
  acceptOrder: (orderId: string, riderId: string, riderName: string) => Promise<boolean>;
  cancelOrder: (orderId: string) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  updateRiderLocation: (orderId: string, lat: number, lng: number) => void;
  getOrdersByCustomer: (customerId: string) => Order[];
  getOrdersByRider: (riderId: string) => Order[];
  getPendingOrders: () => Order[];
  getActiveOrders: () => Order[];
  getTotalRevenue: () => number;
  getRankedRidersForOrder: (order: Pick<Order, 'pickup'>) => RiderProfile[];
  expandOrderDispatch: (orderId: string) => void;
  sweepExpiredOrders: () => void;
}

export const useOrderStore = create<OrderStore>()((set, get) => ({
  orders: [],
  _initialized: false,
  _subscribed: false,

  initFromServer: async () => {
    if (get()._initialized) return;
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        set({ orders: data, _initialized: true });
        useDebugStore.getState().addLog(`Loaded ${data.length} orders from server on startup`, 'info');
      } else {
        set({ _initialized: true });
      }
    } catch (err: any) {
      console.error('[orderStore] Failed to fetch orders:', err);
      useDebugStore.getState().addLog(`Failed to fetch orders on startup: ${err.message || err}`, 'error');
      set({ _initialized: true });
    }
  },

  subscribeRealtime: () => {
    if (get()._subscribed) return;
    set({ _subscribed: true });

    useDebugStore.getState().addLog('Subscribing to hybrid realtime channel for orders...', 'info');

    orderChannel = createHybridChannel({
      name: 'orders',
      table: 'orders',
      onChange: ({ type, row, oldId }) => {
        if (type === 'DELETE') {
          if (!oldId) return;
          useDebugStore.getState().addLog(`[DELETE] order ${oldId.slice(0, 8)}... removed`, 'receive');
          set(s => ({ orders: s.orders.filter(o => o.id !== oldId) }));
          return;
        }

        if (!row) return;

        try {
          const incoming = mapOrderFromDb(row);
          useDebugStore.getState().addLog(`[SYNC-SUCCESS] ${type} order ${incoming.id.slice(0, 8)}... status=${incoming.status} rider=${incoming.riderName || 'none'}`, 'receive');

          set(s => {
            const exists = s.orders.some(o => o.id === incoming.id);
            if (exists && type === 'INSERT') return s;
            if (exists) {
              return { orders: s.orders.map(o => (o.id === incoming.id ? incoming : o)) };
            }
            return { orders: [incoming, ...s.orders] };
          });
        } catch (err: any) {
          console.error('[orderStore] Error mapping incoming row:', err, 'row:', row);
          useDebugStore.getState().addLog(`[MAPPING-ERROR] Could not map order row: ${err.message || err}`, 'error');
        }
      },
    });
  },

  unsubscribeRealtime: () => {
    if (orderChannel) {
      orderChannel.close();
      orderChannel = null;
    }
    set({ _subscribed: false });
  },

  createOrder: async (data) => {
    const distance = calculateDistance(data.pickup.lat, data.pickup.lng, data.dropoff.lat, data.dropoff.lng);
    const { price } = calculatePrice(distance, data.vehicleType, getDefaultRules());
    const orderType: OrderType = data.orderType || 'instant';

    let dispatchedTo: string[] = [];
    if (orderType === 'instant') {
      const ranked = get().getRankedRidersForOrder({ pickup: data.pickup });
      dispatchedTo = ranked.length > 0 ? [ranked[0].id] : [];
    }

    const orderIdVal = data.id || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `ORD-${generateId()}`);

    const order: Order = {
      id: orderIdVal,
      customerId: data.customerId,
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      pickup: data.pickup,
      dropoff: data.dropoff,
      vehicleType: data.vehicleType,
      packageDescription: data.packageDescription,
      distance,
      price,
      status: 'pending',
      orderType,
      scheduledFor: orderType === 'scheduled' ? data.scheduledFor : undefined,
      createdAt: Date.now(),
      dispatchedTo,
    };

    useDebugStore.getState().addLog(`Optimistically adding local order ${order.id.slice(0, 8)}...`, 'info');

    // Optimistic local update
    set(s => {
      const exists = s.orders.some(o => o.id === order.id);
      if (exists) return s;
      return { orders: [order, ...s.orders] };
    });

    // Persist to server
    try {
      useDebugStore.getState().addLog(`POSTing order ${order.id.slice(0, 8)}... to /api/orders`, 'broadcast');
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', order }),
      });
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`Server returned ${res.status}: ${errText}`);
      }
      useDebugStore.getState().addLog(`Order ${order.id.slice(0, 8)}... saved to DB & broadcast sent`, 'broadcast');
    } catch (err: any) {
      console.error('[orderStore] createOrder API error:', err);
      useDebugStore.getState().addLog(`[API-ERROR] createOrder failed: ${err.message || err}`, 'error');
      throw err;
    }

    if (orderType === 'scheduled') {
      pushNotify(data.customerId, 'Order Scheduled!', `Order ${order.id.slice(0, 8)}... is scheduled for ${formatDate(order.scheduledFor!)}.`);
      fireBrowserNotification('Order Scheduled', `Order ${order.id.slice(0, 8)}... is scheduled for ${formatDate(order.scheduledFor!)}.`);
    } else {
      pushNotify(data.customerId, 'Order Placed!', `Order ${order.id.slice(0, 8)}... placed. Waiting for a rider.`);
      fireBrowserNotification('Order Placed', `Order ${order.id.slice(0, 8)}... placed. Waiting for a rider.`);
    }
    return order;
  },

  acceptOrder: async (orderId, riderId, riderName) => {
    // Requirement 2: Check if rider already has an active order
    const riderOrders = get().getOrdersByRider(riderId);
    const hasActive = riderOrders.some(o => ['accepted', 'picked_up', 'in_transit'].includes(o.status));
    if (hasActive) {
      useDebugStore.getState().addLog(`[ACCEPT-BLOCKED] Rider ${riderName} already has an active order`, 'info');
      return false;
    }

    const order = get().orders.find(o => o.id === orderId);
    if (!order || order.status !== 'pending') return false;

    // Optimistic local update
    set(s => ({
      orders: s.orders.map(o => o.id === orderId ? { ...o, riderId, riderName, status: 'accepted' as OrderStatus, acceptedAt: Date.now() } : o),
    }));

    useDebugStore.getState().addLog(`POSTing accept action for order ${orderId.slice(0, 8)}... by rider ${riderName}`, 'broadcast');

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'accept', orderId, riderId, riderName }),
      });
      const result = await res.json();
      if (!result.ok) {
        useDebugStore.getState().addLog(`[ACCEPT-REJECTED] Order ${orderId.slice(0, 8)}... was already taken`, 'error');
        set(s => ({
          orders: s.orders.map(o => o.id === orderId ? { ...o, riderId: undefined, riderName: undefined, status: 'pending' as OrderStatus, acceptedAt: undefined } : o),
        }));
        return false;
      }
      useDebugStore.getState().addLog(`[ACCEPT-CONFIRMED] Server confirmed accept for ${orderId.slice(0, 8)}...`, 'broadcast');
    } catch (err: any) {
      console.error('[orderStore] acceptOrder API error:', err);
      useDebugStore.getState().addLog(`[ACCEPT-ERROR] acceptOrder API failed: ${err.message || err}`, 'error');
      return false;
    }

    const riderProfile = useAuthStore.getState().allUsers.find(u => u.id === riderId);
    const phone = riderProfile && 'phone' in riderProfile && riderProfile.phone
      ? ` Rider phone: ${riderProfile.phone}.`
      : '';
    pushNotify(order.customerId, 'Rider Assigned!', `A rider is on the way to pickup — ${riderName} accepted order ${orderId.slice(0, 8)}...${phone}`);
    pushNotify(riderId, 'Order Accepted', `You accepted order ${orderId.slice(0, 8)}... Head to pickup.`);
    fireBrowserNotification('Rider Assigned', `${riderName} accepted order ${orderId.slice(0, 8)}... — on the way to pickup.`);
    return true;
  },

  cancelOrder: (orderId) => {
    const order = get().orders.find(o => o.id === orderId);
    set(s => ({
      orders: s.orders.map(o => o.id === orderId && o.status === 'pending' ? { ...o, status: 'cancelled' as OrderStatus } : o),
    }));

    useDebugStore.getState().addLog(`Cancelling order ${orderId.slice(0, 8)}...`, 'broadcast');

    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'cancel', orderId, cancelReason: 'user_cancelled' }),
    }).catch(err => console.error('[orderStore] cancelOrder API error:', err));

    if (order && order.status === 'pending') {
      pushNotify(order.customerId, 'Order Cancelled', `Your order ${orderId.slice(0, 8)}... was cancelled.`);
      if (order.riderId) {
        pushNotify(order.riderId, 'Order Cancelled', `Order ${orderId.slice(0, 8)}... was cancelled by customer.`);
      }
      fireBrowserNotification('Order Cancelled', `Order ${orderId.slice(0, 8)}... was cancelled.`);
    }
  },

  updateOrderStatus: (orderId, status) => {
    const order = get().orders.find(o => o.id === orderId);
    set(s => ({
      orders: s.orders.map(o => {
        if (o.id !== orderId) return o;
        const updates: Partial<Order> = { status };
        if (status === 'picked_up') updates.pickedUpAt = Date.now();
        if (status === 'delivered') updates.deliveredAt = Date.now();
        return { ...o, ...updates };
      }),
    }));

    useDebugStore.getState().addLog(`Updating status for ${orderId.slice(0, 8)}... to ${status}`, 'broadcast');

    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_status', orderId, status }),
    }).catch(err => console.error('[orderStore] updateOrderStatus API error:', err));

    if (!order) return;

    if (status === 'picked_up') {
      pushNotify(order.customerId, 'Package Picked Up', `Your order ${orderId.slice(0, 8)}... picked up and on its way.`);
      if (order.riderId) pushNotify(order.riderId, 'Picked Up', `You picked up order ${orderId.slice(0, 8)}...`);
    } else if (status === 'in_transit') {
      pushNotify(order.customerId, 'In Transit', `Your order ${orderId.slice(0, 8)}... is in transit.`);
      if (order.riderId) pushNotify(order.riderId, 'Delivery Started', `Order ${orderId.slice(0, 8)}... in transit.`);
    } else if (status === 'delivered') {
      pushNotify(order.customerId, 'Delivered 🎉', `Your order ${orderId.slice(0, 8)}... delivered.`);
      if (order.riderId) pushNotify(order.riderId, 'Delivered', `Order ${orderId.slice(0, 8)}... delivered.`);
    }
  },

  updateRiderLocation: (orderId, lat, lng) => {
    set(s => ({
      orders: s.orders.map(o => o.id === orderId ? { ...o, riderLocation: { lat, lng } } : o),
    }));
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_rider_location', orderId, lat, lng }),
    }).catch(() => {});
  },

  getRankedRidersForOrder: (order) => {
    const riders = useAuthStore.getState().allUsers.filter(
      (u): u is RiderProfile => u.role === 'rider',
    );
    return riders
      .filter(r => r.availability === 'online' && r.location)
      .map(r => ({
        rider: r,
        dist: calculateDistance(r.location!.lat, r.location!.lng, order.pickup.lat, order.pickup.lng),
      }))
      .sort((a, b) => a.dist - b.dist)
      .map(x => x.rider);
  },

  expandOrderDispatch: (orderId) => {
    const order = get().orders.find(o => o.id === orderId);
    if (!order || order.status !== 'pending') return;
    const current = order.dispatchedTo || [];
    const ranked = get().getRankedRidersForOrder(order);
    const candidates = ranked.filter(r => !current.includes(r.id)).slice(0, 2).map(r => r.id);
    if (candidates.length === 0) return;

    const newDispatched = [...current, ...candidates.filter(id => !current.includes(id))];
    set(s => ({
      orders: s.orders.map(o => {
        if (o.id !== orderId || o.status !== 'pending') return o;
        return { ...o, dispatchedTo: newDispatched };
      }),
    }));

    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update_dispatched_to', orderId, dispatchedTo: newDispatched }),
    }).catch(() => {});
  },

  sweepExpiredOrders: () => {
    const now = Date.now();
    const ordersNow = get().orders;
    const toCancel: { id: string; customerId: string; reason: string; scheduled: boolean }[] = [];

    for (const o of ordersNow) {
      if (o.status !== 'pending') continue;
      const scheduled = (o.orderType || 'instant') === 'scheduled';

      if (!scheduled) {
        if (now - o.createdAt > AUTO_CANCEL_MS) {
          toCancel.push({ id: o.id, customerId: o.customerId, reason: 'no_riders_available', scheduled: false });
        }
        continue;
      }

      const when = o.scheduledFor ?? o.createdAt;

      if (now >= when - SCHEDULED_DISPATCH_WINDOW_MS && now <= when + SCHEDULED_GRACE_MS && (o.dispatchedTo || []).length === 0) {
        const ranked = get().getRankedRidersForOrder(o);
        if (ranked.length > 0) {
          const firstId = ranked[0].id;
          const newDispatched = [firstId];
          set(s => ({
            orders: s.orders.map(x =>
              x.id === o.id && x.status === 'pending' ? { ...x, dispatchedTo: newDispatched } : x,
            ),
          }));
          fetch('/api/orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'update_dispatched_to', orderId: o.id, dispatchedTo: newDispatched }),
          }).catch(() => {});
        }
      }

      if (now > when + SCHEDULED_GRACE_MS) {
        toCancel.push({ id: o.id, customerId: o.customerId, reason: 'no_riders_available_scheduled', scheduled: true });
      }
    }

    if (toCancel.length === 0) return;

    const ids = new Set(toCancel.map(c => c.id));
    const reasonById = new Map(toCancel.map(c => [c.id, c.reason]));
    set(s => ({
      orders: s.orders.map(o =>
        ids.has(o.id) && o.status === 'pending'
          ? { ...o, status: 'cancelled' as OrderStatus, cancelReason: reasonById.get(o.id) }
          : o,
      ),
    }));

    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'bulk_cancel',
        cancellations: toCancel.map(c => ({ id: c.id, cancelReason: c.reason })),
      }),
    }).catch(() => {});
  },

  getOrdersByCustomer: (customerId) => get().orders.filter(o => o.customerId === customerId),
  getOrdersByRider: (riderId) => get().orders.filter(o => o.riderId === riderId),
  getPendingOrders: () => get().orders.filter(o => o.status === 'pending'),
  getActiveOrders: () => get().orders.filter(o => ['accepted', 'picked_up', 'in_transit'].includes(o.status)),
  getTotalRevenue: () => get().orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.price, 0),
}));