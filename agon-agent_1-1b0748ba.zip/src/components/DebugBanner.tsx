import { useDebugStore, type DebugLog } from '../lib/debugStore';
import { Bug, X, Trash2, ChevronUp, ChevronDown, Radio } from 'lucide-react';
import { useState } from 'react';

export default function DebugBanner() {
  const { logs, visible, toggleVisible, clearLogs } = useDebugStore();
  const [expanded, setExpanded] = useState(false);

  if (!visible) {
    return (
      <button
        onClick={toggleVisible}
        className="fixed bottom-4 right-4 z-[9999] bg-gray-900/90 text-yellow-400 text-xs px-3 py-1.5 rounded-full border border-yellow-500/30 shadow-xl flex items-center gap-1.5 font-mono hover:bg-gray-800 transition"
      >
        <Bug size={13} /> Debug Logs ({logs.length})
      </button>
    );
  }

  const latestLog = logs[0];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] bg-slate-950/95 text-slate-200 border-t border-slate-800 shadow-2xl font-mono text-xs backdrop-blur-md transition-all">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900/80 border-b border-slate-800/60">
        <div className="flex items-center gap-2 font-bold text-amber-400">
          <Bug size={14} className="animate-pulse" />
          <span>REALTIME DEBUG BANNER</span>
          <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-normal">
            Logs: {logs.length}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setExpanded(!expanded)}
            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] flex items-center gap-1 transition"
          >
            {expanded ? <><ChevronDown size={12} /> Collapse</> : <><ChevronUp size={12} /> Expand Logs</>}
          </button>
          <button
            onClick={clearLogs}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-red-400 rounded transition"
            title="Clear logs"
          >
            <Trash2 size={13} />
          </button>
          <button
            onClick={toggleVisible}
            className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition"
            title="Hide banner"
          >
            <X size={13} />
          </button>
        </div>
      </div>

      <div className="px-4 py-1.5 flex items-center gap-2 bg-slate-950">
        <Radio size={12} className="text-emerald-400 shrink-0 animate-pulse" />
        <span className="text-slate-500 text-[10px] shrink-0">LATEST:</span>
        {latestLog ? (
          <span className={`truncate ${
            latestLog.type === 'error' ? 'text-red-400 font-semibold' :
            latestLog.type === 'broadcast' ? 'text-blue-400' :
            latestLog.type === 'receive' ? 'text-emerald-300 font-semibold' : 'text-slate-300'
          }`}>
            [{latestLog.time}] [{latestLog.type.toUpperCase()}] {latestLog.message}
          </span>
        ) : (
          <span className="text-slate-600 italic">No events logged yet. Waiting for order operations...</span>
        )}
      </div>

      {expanded && (
        <div className="max-h-48 overflow-y-auto p-3 space-y-1 bg-slate-950/90 border-t border-slate-900 divide-y divide-slate-900/50">
          {logs.length === 0 ? (
            <p className="text-slate-500 italic text-center py-2">No debug logs captured yet.</p>
          ) : (
            logs.map((log: DebugLog) => (
              <div key={log.id} className="pt-1 flex items-start gap-2 text-[11px] leading-relaxed">
                <span className="text-slate-500 shrink-0 font-mono text-[10px]">{log.time}</span>
                <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold uppercase shrink-0 ${
                  log.type === 'error' ? 'bg-red-950 text-red-400 border border-red-800/40' :
                  log.type === 'broadcast' ? 'bg-blue-950 text-blue-400 border border-blue-800/40' :
                  log.type === 'receive' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40' :
                  'bg-slate-800 text-slate-300'
                }`}>
                  {log.type}
                </span>
                <span className={`break-all ${
                  log.type === 'error' ? 'text-red-300 font-medium' :
                  log.type === 'receive' ? 'text-emerald-200' : 'text-slate-300'
                }`}>
                  {log.message}
                </span>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
