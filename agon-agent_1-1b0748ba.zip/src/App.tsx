import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useThemeStore } from './stores/themeStore';
import { useOrderStore } from './stores/orderStore';
import { useNotificationStore } from './stores/notificationStore';
import { useAuthStore } from './stores/authStore';
import { requestNotifyPermission } from './lib/browserNotify';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppFloat from './components/WhatsAppFloat';
import ToastContainer from './components/Toast';
import DebugBanner from './components/DebugBanner';
import Home from './pages/Home';
import Services from './pages/Services';
import Book from './pages/Book';
import Track from './pages/Track';
import About from './pages/About';
import Contact from './pages/Contact';
import { LoginPage, SignupPage, ManagerLoginPage } from './pages/Auth';
import RiderDashboard from './pages/RiderDashboard';
import ManagerDashboard from './pages/ManagerDashboard';
import Profile from './pages/Profile';
import MyOrders from './pages/MyOrders';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

const FULL_SCREEN_ROUTES = ['/book', '/track'];

function AppContent() {
  const theme = useThemeStore(s => s.theme);
  const { pathname } = useLocation();
  const isFullScreen = FULL_SCREEN_ROUTES.includes(pathname);
  const user = useAuthStore(s => s.user);

  useEffect(() => {
    useOrderStore.getState().initFromServer();
    useNotificationStore.getState().initFromServer();
  }, []);

  useEffect(() => {
    useOrderStore.getState().subscribeRealtime();
    useNotificationStore.getState().subscribeRealtime();

    return () => {
      useOrderStore.getState().unsubscribeRealtime();
      useNotificationStore.getState().unsubscribeRealtime();
    };
  }, []);

  useEffect(() => {
    if (user) requestNotifyPermission();
  }, [user?.id]);

  useEffect(() => {
    useOrderStore.getState().sweepExpiredOrders();
    const iv = setInterval(() => useOrderStore.getState().sweepExpiredOrders(), 15000);
    return () => clearInterval(iv);
  }, []);

  return (
    <div className={theme === 'dark' ? 'theme-dark' : 'theme-light'}>
      <ScrollToTop />
      <Navbar />
      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/book" element={<Book />} />
          <Route path="/track" element={<Track />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/auth/login" element={<LoginPage />} />
          <Route path="/auth/signup" element={<SignupPage />} />
          <Route path="/manager/login" element={<ManagerLoginPage />} />
          <Route path="/rider/dashboard" element={<RiderDashboard />} />
          <Route path="/manager" element={<ManagerDashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/my-orders" element={<MyOrders />} />
        </Routes>
      </main>
      {!isFullScreen && <Footer />}
      {!isFullScreen && <WhatsAppFloat />}
      <ToastContainer />
      <DebugBanner />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
