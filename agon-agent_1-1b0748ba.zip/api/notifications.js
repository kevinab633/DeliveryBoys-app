import supabase from './db-client.js';
import { broadcastChange } from './_broadcast.js';

const TOPIC = 'notifications-sync';
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function ensureUuid(id) {
  if (id && UUID_REGEX.test(id)) return id;
  if (typeof globalThis.crypto !== 'undefined' && globalThis.crypto.randomUUID) {
    return globalThis.crypto.randomUUID();
  }
  return '00000000-0000-4000-8000-' + String(Date.now()).padStart(12, '0').slice(-12);
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { userId } = req.query;
      let query = supabase
        .from('notifications')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      if (userId) {
        query = query.eq('user_id', userId);
      }
      const { data, error } = await query;
      if (error) throw error;
      const mapped = (data || []).map(mapNotifFromDb);
      return res.status(200).json(mapped);
    }

    if (req.method === 'POST') {
      const { action } = req.body;

      if (action === 'create') {
        const n = req.body.notification;
        const row = mapNotifToDb(n);
        const { data, error } = await supabase
          .from('notifications')
          .insert(row)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'INSERT', { row: data });
        return res.status(201).json(mapNotifFromDb(data));
      }

      if (action === 'mark_read') {
        const { id } = req.body;
        const dbId = ensureUuid(id);
        const { data, error } = await supabase
          .from('notifications')
          .update({ read: true })
          .eq('id', dbId)
          .select()
          .maybeSingle();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapNotifFromDb(data) : { ok: true });
      }

      if (action === 'mark_all_read') {
        const { userId } = req.body;
        const { data, error } = await supabase
          .from('notifications')
          .update({ read: true })
          .eq('user_id', userId)
          .eq('read', false)
          .select();
        if (error) throw error;
        for (const row of data || []) await broadcastChange(TOPIC, 'UPDATE', { row });
        return res.status(200).json({ ok: true });
      }

      return res.status(400).json({ error: 'Unknown action' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /notifications error:', err);
    res.status(500).json({ error: err.message });
  }
}

function mapNotifToDb(n) {
  const row = {
    id: ensureUuid(n.id),
    user_id: n.userId || null,
    title: n.title || '',
    message: n.message || '',
    type: n.type || 'order',
    read: Boolean(n.read),
  };
  if (n.createdAt) {
    row.created_at = typeof n.createdAt === 'number' ? new Date(n.createdAt).toISOString() : n.createdAt;
  }
  return row;
}

function mapNotifFromDb(row) {
  const createdAt = row.created_at ? new Date(row.created_at).getTime() : Date.now();
  return {
    id: row.id,
    userId: row.user_id || '',
    title: row.title || '',
    message: row.message || '',
    type: row.type || 'order',
    read: Boolean(row.read),
    createdAt,
  };
}
