// Server-side Realtime broadcast helper.
//
// Pushes a change event to every subscribed client over Supabase Realtime
// using the HTTP broadcast endpoint.

const SUPABASE_URL =
  process.env.VITE_SUPABASE_URL ||
  process.env.NEXT_PUBLIC_SUPABASE_URL ||
  'https://ratrzbrsyaxfobjbfipl.supabase.co';

const SERVICE_KEY =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.VITE_SUPABASE_ANON_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJhdHJ6YnJzeWF4Zm9iamJmaXBsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgwODM5MjMsImV4cCI6MjEwMzY1OTkyM30.u4jlQMsTzFb3Oy41cs0njMTmKIAUo16FfNwaBWEonWM';

/**
 * @param {string} topic  Channel topic, e.g. "orders-sync"
 * @param {'INSERT'|'UPDATE'|'DELETE'} type
 * @param {object} payload  { row } or { oldId }
 */
export async function broadcastChange(topic, type, payload) {
  if (!SUPABASE_URL || !SERVICE_KEY) return;
  try {
    await fetch(`${SUPABASE_URL}/realtime/v1/api/broadcast`, {
      method: 'POST',
      headers: {
        apikey: SERVICE_KEY,
        Authorization: `Bearer ${SERVICE_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messages: [{ topic, event: 'change', payload: { type, ...payload } }],
      }),
    });
  } catch (err) {
    console.error('[broadcast] failed:', err.message);
  }
}
