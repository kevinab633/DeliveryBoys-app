import supabase from './db-client.js';
import { broadcastChange } from './_broadcast.js';

const TOPIC = 'orders-sync';
const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function ensureUuid(id) {
  if (id && UUID_REGEX.test(id)) return id;
  if (typeof globalThis.crypto !== 'undefined' && globalThis.crypto.randomUUID) {
    return globalThis.crypto.randomUUID();
  }
  return '00000000-0000-4000-8000-' + String(Date.now()).padStart(12, '0').slice(-12);
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      const mapped = (data || []).map(mapOrderFromDb);
      return res.status(200).json(mapped);
    }

    if (req.method === 'POST') {
      const { action } = req.body;

      if (action === 'create') {
        const o = req.body.order;
        const row = mapOrderToDb(o);
        const { data, error } = await supabase
          .from('orders')
          .insert(row)
          .select()
          .single();
        if (error) throw error;
        await broadcastChange(TOPIC, 'INSERT', { row: data });
        return res.status(201).json(mapOrderFromDb(data));
      }

      if (action === 'accept') {
        const { orderId, riderId, riderName } = req.body;
        const dbId = ensureUuid(orderId);
        const { data: existing } = await supabase
          .from('orders')
          .select('status')
          .eq('id', dbId)
          .maybeSingle();
        if (!existing || existing.status !== 'pending') {
          return res.status(200).json({ ok: false, reason: 'already_taken' });
        }
        const { data, error } = await supabase
          .from('orders')
          .update({
            rider_id: riderId,
            rider_name: riderName,
            status: 'accepted',
          })
          .eq('id', dbId)
          .eq('status', 'pending')
          .select()
          .maybeSingle();
        if (error) throw error;
        if (!data) return res.status(200).json({ ok: false, reason: 'already_taken' });
        await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json({ ok: true, order: mapOrderFromDb(data) });
      }

      if (action === 'update_status') {
        const { orderId, status } = req.body;
        const dbId = ensureUuid(orderId);
        const updates = { status };
        const { data, error } = await supabase
          .from('orders')
          .update(updates)
          .eq('id', dbId)
          .select()
          .maybeSingle();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapOrderFromDb(data) : { ok: false });
      }

      if (action === 'cancel') {
        const { orderId, cancelReason } = req.body;
        const dbId = ensureUuid(orderId);
        const { data, error } = await supabase
          .from('orders')
          .update({ status: 'cancelled', cancel_reason: cancelReason || 'user_cancelled' })
          .eq('id', dbId)
          .eq('status', 'pending')
          .select()
          .maybeSingle();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapOrderFromDb(data) : { ok: false });
      }

      if (action === 'update_rider_location') {
        const { orderId, lat, lng } = req.body;
        const dbId = ensureUuid(orderId);
        const { data, error } = await supabase
          .from('orders')
          .update({ rider_location: { lat, lng } })
          .eq('id', dbId)
          .select()
          .maybeSingle();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapOrderFromDb(data) : { ok: false });
      }

      if (action === 'update_dispatched_to') {
        const { orderId, dispatchedTo } = req.body;
        const dbId = ensureUuid(orderId);
        const { data, error } = await supabase
          .from('orders')
          .update({ dispatched_to: dispatchedTo })
          .eq('id', dbId)
          .select()
          .maybeSingle();
        if (error) throw error;
        if (data) await broadcastChange(TOPIC, 'UPDATE', { row: data });
        return res.status(200).json(data ? mapOrderFromDb(data) : { ok: false });
      }

      if (action === 'bulk_cancel') {
        const { cancellations } = req.body;
        for (const c of cancellations || []) {
          const dbId = ensureUuid(c.id);
          const { data: row } = await supabase
            .from('orders')
            .update({ status: 'cancelled', cancel_reason: c.cancelReason })
            .eq('id', dbId)
            .eq('status', 'pending')
            .select()
            .maybeSingle();
          if (row) await broadcastChange(TOPIC, 'UPDATE', { row });
        }
        return res.status(200).json({ ok: true });
      }

      return res.status(400).json({ error: 'Unknown action' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('API /orders error:', err);
    res.status(500).json({ error: err.message });
  }
}

function mapOrderToDb(o) {
  const dbId = ensureUuid(o.id);
  const pickup = o.pickup ? {
    ...o.pickup,
    distance: o.distance,
    customerName: o.customerName || o.pickup.customerName,
    customerPhone: o.customerPhone || o.pickup.customerPhone,
  } : o.pickup;

  const row = {
    id: dbId,
    customer_id: o.customerId || null,
    rider_id: o.riderId || null,
    rider_name: o.riderName || null,
    pickup,
    dropoff: o.dropoff || null,
    price: o.price || 0,
    status: o.status || 'pending',
    vehicle_type: o.vehicleType || 'motorcycle',
    package_description: o.packageDescription || null,
    order_type: o.orderType || 'instant',
    scheduled_for: o.scheduledFor || null,
    dispatched_to: o.dispatchedTo || null,
    rider_location: o.riderLocation || null,
    cancel_reason: o.cancelReason || null,
  };

  if (o.createdAt) {
    row.created_at = typeof o.createdAt === 'number' ? new Date(o.createdAt).toISOString() : o.createdAt;
  }
  return row;
}

function mapOrderFromDb(row) {
  const pickup = row.pickup || {};
  const customerName = pickup.customerName || 'Customer';
  const customerPhone = pickup.customerPhone || '';
  const distance = pickup.distance || 0;
  const createdAt = row.created_at ? new Date(row.created_at).getTime() : Date.now();

  return {
    id: row.id,
    customerId: row.customer_id || '',
    customerName,
    customerPhone,
    riderId: row.rider_id || undefined,
    riderName: row.rider_name || undefined,
    pickup,
    dropoff: row.dropoff,
    distance,
    price: row.price || 0,
    status: row.status,
    vehicleType: row.vehicle_type,
    packageDescription: row.package_description,
    createdAt,
    acceptedAt: row.accepted_at ? new Date(row.accepted_at).getTime() : undefined,
    pickedUpAt: row.picked_up_at ? new Date(row.picked_up_at).getTime() : undefined,
    deliveredAt: row.delivered_at ? new Date(row.delivered_at).getTime() : undefined,
    riderLocation: row.rider_location || undefined,
    orderType: row.order_type || 'instant',
    scheduledFor: row.scheduled_for || undefined,
    dispatchedTo: row.dispatched_to || undefined,
    cancelReason: row.cancel_reason || undefined,
  };
}
