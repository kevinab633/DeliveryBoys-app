-- ============================================================================
-- Delivery Boys — Realtime replication + Row Level Security
-- ----------------------------------------------------------------------------
-- Run this once in the Supabase dashboard: SQL Editor -> New query -> Run.
--
-- These statements are DDL and cannot be executed through the Supabase JS
-- client / PostgREST, which is why they are provided here as a migration.
--
-- The app already works without this file (live sync runs over Realtime
-- Broadcast). Running it additionally enables the native `postgres_changes`
-- WAL stream and turns on RLS. The client subscribes to both transports and
-- de-duplicates by row id, so nothing breaks when you enable replication.
-- ============================================================================


-- 1. ─────────────────────────── REALTIME REPLICATION ───────────────────────
-- Add the tables to the Realtime publication. Guarded so re-running is safe.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'orders'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND schemaname = 'public' AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
  END IF;
END $$;

-- UPDATE/DELETE events only carry the primary key by default. FULL replica
-- identity makes the complete previous row available to subscribers.
ALTER TABLE public.orders        REPLICA IDENTITY FULL;
ALTER TABLE public.notifications REPLICA IDENTITY FULL;


-- 2. ────────────────────────── ROW LEVEL SECURITY ──────────────────────────
-- RLS is ENABLED (never disabled) and backed by explicit policies.

ALTER TABLE public.orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- IMPORTANT CONTEXT -----------------------------------------------------------
-- This app does NOT use Supabase Auth. `src/stores/authStore.ts` is a custom
-- zustand + localStorage store with a mocked OTP flow, so `auth.uid()` is
-- ALWAYS NULL for the browser client.
--
-- Consequences:
--   * Every write already goes through the /api/* routes using the SERVICE
--     ROLE key, which bypasses RLS entirely. So RLS never gates writes here.
--   * Realtime `postgres_changes` evaluates RLS AS THE SUBSCRIBER (anon).
--     A policy such as `auth.uid() = customer_id` would therefore match zero
--     rows and silently deliver ZERO realtime events.
--
-- So the policies below grant READ to anon/authenticated (which exposes no
-- more than the existing public /api/orders endpoint already does) and grant
-- NO direct write access — writes are forced through the API routes.
-- See section 3 for the per-user lockdown once Supabase Auth is adopted.

DROP POLICY IF EXISTS orders_public_read_for_realtime        ON public.orders;
DROP POLICY IF EXISTS orders_read_all                        ON public.orders;
DROP POLICY IF EXISTS notifications_public_read_for_realtime ON public.notifications;

CREATE POLICY orders_read_all
  ON public.orders FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY notifications_read_all
  ON public.notifications FOR SELECT
  TO anon, authenticated
  USING (true);

-- No INSERT / UPDATE / DELETE policies are defined for anon or authenticated.
-- With RLS enabled and no matching policy, direct writes with the publishable
-- (anon) key are rejected. This closes a real hole: before RLS was enabled,
-- anyone holding the public key could INSERT, UPDATE and DELETE orders.


-- 3. ──────────────── OPTIONAL: per-user isolation (Supabase Auth) ──────────
-- Apply ONLY after migrating authStore.ts to real Supabase Auth, and after
-- making customer_id / rider_id / user_id hold auth.uid() values.
-- Until then these would break both reads and realtime.
--
-- DROP POLICY IF EXISTS orders_read_all ON public.orders;
--
-- -- Customers see their own orders; riders see theirs plus unassigned pending
-- -- work they are allowed to accept.
-- CREATE POLICY orders_select_own ON public.orders FOR SELECT TO authenticated
--   USING (
--     auth.uid()::text = customer_id
--     OR auth.uid()::text = rider_id
--     OR (status = 'pending' AND rider_id IS NULL)
--   );
--
-- -- Customers create orders only for themselves.
-- CREATE POLICY orders_insert_own ON public.orders FOR INSERT TO authenticated
--   WITH CHECK (auth.uid()::text = customer_id);
--
-- -- A rider may claim a pending order, or update one already assigned to them;
-- -- a customer may update their own order (e.g. cancel).
-- CREATE POLICY orders_update_participant ON public.orders FOR UPDATE TO authenticated
--   USING (
--     auth.uid()::text = customer_id
--     OR auth.uid()::text = rider_id
--     OR (status = 'pending' AND rider_id IS NULL)
--   )
--   WITH CHECK (auth.uid()::text = customer_id OR auth.uid()::text = rider_id);
--
-- DROP POLICY IF EXISTS notifications_read_all ON public.notifications;
--
-- CREATE POLICY notifications_select_own ON public.notifications FOR SELECT TO authenticated
--   USING (auth.uid()::text = user_id);
--
-- CREATE POLICY notifications_update_own ON public.notifications FOR UPDATE TO authenticated
--   USING (auth.uid()::text = user_id)
--   WITH CHECK (auth.uid()::text = user_id);


-- 4. ──────────────────────────── VERIFICATION ──────────────────────────────
-- Expect one row per table.
SELECT schemaname, tablename
  FROM pg_publication_tables
 WHERE pubname = 'supabase_realtime'
   AND tablename IN ('orders', 'notifications');

-- Expect rowsecurity = true for both.
SELECT relname AS table_name, relrowsecurity AS rls_enabled
  FROM pg_class
 WHERE relname IN ('orders', 'notifications');

-- Expect the read policies listed above.
SELECT tablename, policyname, cmd, roles
  FROM pg_policies
 WHERE tablename IN ('orders', 'notifications');
